function [X, res, Out] = Cloud_BTR(Y,Mask,opts)
if isfield(opts, 'tol');         tol   = opts.tol;              end
if isfield(opts, 'maxit');       maxit = opts.maxit;    end
if isfield(opts, 'rho');         rho   = opts.rho;              end
if isfield(opts, 'allR');        allR      = opts.allR;        end
if isfield(opts, 'beta1');       beta1     = opts.beta1;        end
if isfield(opts, 'beta2');       beta2     = opts.beta2;        end
if isfield(opts, 'alpha');       alpha     = opts.alpha;        end
Nway = size(Y);

Mask  = repmat(Mask,1,1,1,Nway(3));
Mask  = permute(Mask,[1,2,4,3]);

tempY = Y.*Mask;
tempX = sum(tempY,4)./(sum(Mask,4)+0.00000000001);
X = tempY+repmat(tempX,[1,1,1,Nway(4)]).*(1-Mask);


R1=allR(1); R2=allR(2); R=allR(3);

G = cell(1,3);
G{1} = ones(R1,Nway(1),R1);
G{2} = ones(R1,Nway(2),R1);
G{3} = ones(R1,R,R1);

F = cell(1,3);
F{1} = ones(R2,R,R2);
F{2} = ones(R2,Nway(3),R2);
F{3} = ones(R2,Nway(4),R2);

A = ones(Nway(1),Nway(2),R); 
B = ones(R,Nway(3),Nway(4)); 

Out.Res=[];Out.PSNR=[];

for k = 1:maxit
    Xold = X;
   
    %% Update A
    Xi = reshape(X,[prod([Nway(1),Nway(2)]),prod([Nway(3),Nway(4)])]);
    Ai = reshape(A,[],R);
    Bi = reshape(B,R,[]);
    C  = TR_ybz(G);
    Ci = reshape(C,[],R);
    tempC = alpha*Xi*Bi'+beta1*Ci+rho*Ai;
    tempA = alpha*(Bi*Bi')+(rho+beta1)*eye(R);
    A     = reshape(tempC*pinv(tempA),size(A));

    %% Update B
    Ai = reshape(A,[],R);
    D  = TR_ybz(F);
    Di = reshape(D,R,[]);
    tempC =alpha*Ai'*Xi+beta2*Di+rho*Bi;
    tempA = alpha*(Ai'*Ai)+(rho+beta2)*eye(R);
    B = reshape(pinv(tempA)*tempC,size(B));

    %% Update G_1,2,3 
    for i = 1:3
        Gi = Unfold(G{i},size(G{i}),2);
        Ai = Unfold(A,size(A),i);
        Mi = BTR_rest_ybz(G, i);
        tempC = beta1*Ai*Mi'+rho*Gi;
        tempA = beta1*(Mi*Mi')+rho*eye(size(Gi,2));
        G{i}  = Fold(tempC*pinv(tempA),size(G{i}),2);
    end
    
    %% Update F_1,2,3 
    for i = 1:3
        Fi = Unfold(F{i},size(F{i}),2);
        Bi = Unfold(B,size(B),i);
        Mi = BTR_rest_ybz(F, i);
        tempC = beta1*Bi*Mi'+rho*Fi;
        tempA = beta1*(Mi*Mi')+rho*eye(size(Fi,2));
        F{i}  = Fold(tempC*pinv(tempA),size(F{i}),2);
    end
    
   
    %% Update X 
    AB = tensor_contraction_ybz(A,B,3,1);
    X  = Y.*Mask+(alpha*AB+rho*Xold)/(alpha+rho).*(1-Mask);
   
    %% check the convergence
    if isfield(opts, 'Xtrue')
        XT=opts.Xtrue;
        psnr= my_PSNR(X(:,:,:,1:3)*255,XT(:,:,:,1:3)*255);
        Out.PSNR = [Out.PSNR,psnr];
    end
    res=norm(X(:)-Xold(:))/norm(Xold(:));
    Out.Res = [Out.Res,res];
    
    if mod(k, 10) == 0
        if isfield(opts, 'Xtrue')
            fprintf('Cloud_Removal_BTR: iter = %d   PSNR=%f   res=%f   \n', k, psnr, res);
        else
            fprintf('Cloud_Removal_BTR: iter = %d   res=%f   \n', k, res);
        end
    end
    if res < tol 
        break;
    end
end
end

function Out = TR_ybz(G)
    Out = tensor_contraction_ybz(tensor_contraction_ybz(G{1},G{2},3,1),G{3},[4,1],[1,3]);
end

function Out = BTR_rest_ybz(G,i)
    n=[1,4]; m=[2,3];
    if i == 1
        GI=tensor_contraction_ybz(G{2},G{3},3,1);
    end
    if i == 2
        GI=tensor_contraction_ybz(G{3},G{1},3,1);
    end
    if i == 3
        GI=tensor_contraction_ybz(G{1},G{2},3,1);
    end
    NwayOut = size(GI);
    GI= permute(GI,[n,m]);
    Out = reshape(GI,prod(NwayOut(n)),prod(NwayOut(m)));
end


function W = Unfold(W, dim, i)
         W = reshape(shiftdim(W,i-1), dim(i), []);
end 

function W = Fold(W, dim, i)
         dim = circshift(dim, [1-i, 1-i]);
         W = shiftdim(reshape(W, dim), length(dim)+1-i);
end


