function p = psnr_index(x,y)
p=10*log10(255^2/mse(x-y));

function MSE = mse(X)
MSE = sum(X(:).*X(:))/numel(X);


