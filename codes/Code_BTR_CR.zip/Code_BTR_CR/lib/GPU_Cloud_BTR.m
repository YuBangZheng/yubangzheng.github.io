function [X, res, Out] = GPU_Cloud_BTR(Y, Mask, opts)
%% Options
if isfield(opts, 'tol');   tol   = opts.tol;    else, tol = 1e-4; end
if isfield(opts, 'maxit'); maxit = opts.maxit;  else, maxit = 200; end
if isfield(opts, 'rho');   rho   = opts.rho;    else, rho = 1; end
if isfield(opts, 'allR');  allR  = opts.allR;   else, allR = [6 6 6]; end
if isfield(opts, 'beta1'); beta1 = opts.beta1;  else, beta1 = 1; end
if isfield(opts, 'beta2'); beta2 = opts.beta2;  else, beta2 = 1; end
if isfield(opts, 'alpha'); alpha = opts.alpha;  else, alpha = 1; end

%% GPU Setup
Y = gpuArray(Y);
Mask = gpuArray(Mask);
Nway = size(Y);
Mask = repmat(Mask, 1, 1, 1, Nway(3));
Mask = permute(Mask, [1, 2, 4, 3]);

tempY = Y .* Mask;
tempX = sum(tempY, 4) ./ (sum(Mask, 4) + 1e-10);
X = tempY + repmat(tempX, [1, 1, 1, Nway(4)]) .* (1 - Mask);

R1 = allR(1); R2 = allR(2); R = allR(3);

G = {gpuArray(ones(R1, Nway(1), R1)), ...
     gpuArray(ones(R1, Nway(2), R1)), ...
     gpuArray(ones(R1, R, R1))};

F = {gpuArray(ones(R2, R, R2)), ...
     gpuArray(ones(R2, Nway(3), R2)), ...
     gpuArray(ones(R2, Nway(4), R2))};

A = gpuArray(ones(Nway(1), Nway(2), R));
B = gpuArray(ones(R, Nway(3), Nway(4)));

Out.Res = [];
Out.PSNR = [];

%% Iteration
for k = 1:maxit
    Xold = X;

    %% Update A
    Xi = reshape(X, [], prod(Nway(3:4)));
    Ai = reshape(A, [], R);
    Bi = reshape(B, R, []);
    C = TR_ybz(G);
    Ci = reshape(C, [], R);

    tempC = alpha * Xi * Bi' + beta1 * Ci + rho * Ai;
    tempA = alpha * (Bi * Bi') + (rho + beta1) * eye(R, 'like', Bi);
    A = reshape(tempC / tempA, size(A));

    %% Update B
    Ai = reshape(A, [], R);
    D = TR_ybz(F);
    Di = reshape(D, R, []);
    tempC = alpha * Ai' * Xi + beta2 * Di + rho * Bi;
    tempA = alpha * (Ai' * Ai) + (rho + beta2) * eye(R, 'like', Ai);
    B = reshape(tempA \ tempC, size(B));

    %% Update G
    for i = 1:3
        Gi = Unfold(G{i}, size(G{i}), 2);
        Ai = Unfold(A, size(A), i);
        Mi = BTR_rest_ybz(G, i);
        tempC = beta1 * Ai * Mi' + rho * Gi;
        tempA = beta1 * (Mi * Mi') + rho * eye(size(Gi, 2), 'like', Gi);
        G{i} = Fold(tempC / tempA, size(G{i}), 2);
    end

    %% Update F
    for i = 1:3
        Fi = Unfold(F{i}, size(F{i}), 2);
        Bi = Unfold(B, size(B), i);
        Mi = BTR_rest_ybz(F, i);
        tempC = beta2 * Bi * Mi' + rho * Fi;
        tempA = beta2 * (Mi * Mi') + rho * eye(size(Fi, 2), 'like', Fi);
        F{i} = Fold(tempC / tempA, size(F{i}), 2);
    end

    %% Update X
    AB = tensor_contraction_ybz(A, B, 3, 1);
    X = Y .* Mask + ((alpha * AB + rho * Xold) / (alpha + rho)) .* (1 - Mask);

    %% Convergence check
    if isfield(opts, 'Xtrue')
        XT = gpuArray(opts.Xtrue);
        psnr = my_PSNR(gather(X(:,:,:,1:3) * 255), gather(XT(:,:,:,1:3) * 255));
        Out.PSNR = [Out.PSNR, psnr];
    end

    res = norm(X(:) - Xold(:)) / norm(Xold(:));
    Out.Res = [Out.Res, gather(res)];

    if mod(k, 10) == 0
        if isfield(opts, 'Xtrue')
            fprintf('Cloud_Removal_BTR: iter = %d   PSNR = %f   res = %f\n', k, psnr, res);
        else
            fprintf('Cloud_Removal_BTR: iter = %d   res = %f\n', k, res);
        end
    end

    if res < tol
        break;
    end
end

X = gather(X);
res = gather(res);
end

%% Helper: Tensor Ring Product
function Out = TR_ybz(G)
    Out = tensor_contraction_ybz(tensor_contraction_ybz(G{1}, G{2}, 3, 1), G{3}, [4, 1], [1, 3]);
end

%% Helper: Rest Tensor Product
function Out = BTR_rest_ybz(G, i)
    if i == 1
        GI = tensor_contraction_ybz(G{2}, G{3}, 3, 1);
    elseif i == 2
        GI = tensor_contraction_ybz(G{3}, G{1}, 3, 1);
    else
        GI = tensor_contraction_ybz(G{1}, G{2}, 3, 1);
    end
    NwayOut = size(GI);
    GI = permute(GI, [1, 4, 2, 3]); % [1 4] and [2 3] pattern
    Out = reshape(GI, prod(NwayOut([1, 4])), prod(NwayOut([2, 3])));
end

%% Helper: Unfold a tensor along mode-i
function W = Unfold(W, dim, i)
    W = reshape(shiftdim(W, i - 1), dim(i), []);
end

%% Helper: Fold a matrix back into a tensor along mode-i
function W = Fold(W, dim, i)
    dim = circshift(dim, [1 - i, 1 - i]);
    W = shiftdim(reshape(W, dim), length(dim) + 1 - i);
end
