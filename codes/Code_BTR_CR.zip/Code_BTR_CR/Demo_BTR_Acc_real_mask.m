clc;
clear;
close all;
addpath(genpath('lib'));
addpath(genpath('data'));

%% Load initial data
load('america_2.mat')
load('Mask.mat')
Mask =1-Mask;
Cloudy_image = Clean;
for i=1:3
    Cloudy_image(:,:,:,i)=Cloudy_image(:,:,:,i).*Mask(:,:,i)+1-Mask(:,:,i);
end
opts=[];
opts.allR   = [4,2,40];% 
opts.tol    = 1e-4;
opts.alpha  = 1;
opts.beta1  = 1;%
opts.beta2  = 1;%
opts.maxit  = 100;
opts.rho    = 0.01;
opts.Xtrue  = Clean;
%%%%%
fprintf('\n');
disp('performing BTR method for Cloud Removal... ');
t0= tic;
[Re_image,res,Out]      = Cloud_BTR(Cloudy_image,Mask,opts);
%[Re_image,res,Out]      = GPU_Cloud_BTR(Cloudy_image,Mask,opts);
time         = toc(t0);
[psnr, ssim] = my_quality(Clean(:,:,:,1:3)*255, Re_image(:,:,:,1:3)*255);


%% show image
fig = figure('Units', 'normalized', 'OuterPosition', [0 0 1 1]);
subplot(1,3,1);
imshow(Clean(:,:,[4 3 2],1) * 4);
title('Clean Image', 'FontSize', 24);
axis image off;
subplot(1,3,2);
imshow(Cloudy_image(:,:,[4 3 2],1) * 4);
title('Cloudy Image', 'FontSize', 24);
axis image off;
subplot(1,3,3);
imshow(Re_image(:,:,[4 3 2],1) * 4);
title('Reconstructed Image', 'FontSize', 24);
axis image off;

