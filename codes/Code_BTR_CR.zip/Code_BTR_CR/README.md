# Bilateral Tensor Ring Decomposition for Thick Cloud Removal in Multitemporal Remote Sensing Images

**Authors**: Yu-Bang Zheng, Jia-Le Ma, Heng-Chao Li*, Zhi-Wei Shi, Qing Zhu  
**Published in**: *IEEE Transactions on Geoscience and Remote Sensing*, 2025  
**DOI**: [10.1109/TGRS.2025.3598118](https://doi.org/10.1109/TGRS.2025.3598118)

---

### 📌 Overview
This repository contains the **MATLAB implementation** of the **Bilateral Tensor Ring (BTR) Decomposition** method for **thick cloud removal** in multitemporal remote sensing images, as proposed in our IEEE TGRS paper.

---

### 📂 File Structure
```
Code_BTR_CR/
│
├── Demo_BTR_Acc_real_mask.m        % Example with accurate real cloud mask
├── Demo_BTR_Acc_simulated_mask.m   % Example with accurate simulated cloud mask
├── Demo_BTR_Ina_simulated_mask.m   % Example with inaccurate simulated cloud mask
│
├── data/                           % Example datasets
│   ├── Mask.mat
│   ├── america_2.mat
│   ├── inaMask_3.mat
│   ├── inaMask_ini.mat
│
├── lib/                            % Core algorithms & utilities
│   ├── Cloud_BTR.m                 % BTR for accurate mask (CPU)
│   ├── GPU_Cloud_BTR.m             % BTR for accurate mask (GPU)
│   ├── Ina_Cloud_BTR.m             % BTR for inaccurate mask (CPU)
│   ├── GPU_Ina_Cloud_BTR.m         % BTR for inaccurate mask (GPU)
│   ├── tensor_contraction_ybz.m    % Tensor contraction operation
│   └── quality_assess/             % Image quality evaluation metrics
│       ├── my_PSNR.m
│       ├── my_quality.m
│       ├── psnr_index.m
│       ├── ssim_index.m
```

---

### 🚀 How to Run

  1. **Run Example Scripts**
   - **Accurate real mask:**
     ```matlab
     Demo_BTR_Acc_real_mask
     ```
   - **Accurate simulated mask:**
     ```matlab
     Demo_BTR_Acc_simulated_mask
     ```
   - **Inaccurate simulated mask:**
     ```matlab
     Demo_BTR_Ina_simulated_mask
     ```

3. **Outputs**
   - Reconstructed cloud-free images.
   - PSNR/SSIM evaluation results (if reference images are available).

---

### 📄 Citation
If you use this code, please cite:
```
Yu-Bang Zheng, Jia-Le Ma, Heng-Chao Li*, Zhi-Wei Shi, Qing Zhu,
"Bilateral Tensor Ring Decomposition for Thick Cloud Removal in Multitemporal Remote Sensing Images",
IEEE Transactions on Geoscience and Remote Sensing, 2025.
doi:10.1109/TGRS.2025.3598118
```
