%% =================================================================
% This script runs the FCTNFR-based TC method
%
% More detail can be found in [1]
% [1] Yu-Bang Zheng, Ting-Zhu Huang*, Xi-Le Zhao*, Qibin Zhao
%     Tensor Completion via Fully-Connected Tensor Network Decomposition
%     with Regularized Factors
%
% Please make sure your data is in range [0, 1].
%
% Created by Yu-Bang Zheng (zhengyubang@163.com)
% Feb. 06, 2021
% Updated by Yu-Bang Zheng
% Mar. 10, 2022

%% =================================================================
clc;
clear;
close all;
addpath(genpath('lib'));
addpath(genpath('data'));

%%
methodname    = {'Observed', 'FCTN-TC'};
Mnum          = length(methodname);
Re_tensor     = cell(Mnum,1);
psnr          = zeros(Mnum,1);
ssim          = zeros(Mnum,1);
time          = zeros(Mnum,1);

%% Load initial data
load('test_news.mat')
if max(X(:))>1
    X = X/max(X(:));
end

%% Sampling with random position
sample_ratio = 0.05;
fprintf('=== The sample ratio is %4.2f ===\n', sample_ratio);
Y_tensorT = X;
Ndim      = ndims(Y_tensorT);
Nway      = size(Y_tensorT);
Omega     = find(rand(prod(Nway),1)<sample_ratio);
F         = zeros(Nway);
F(Omega)  = Y_tensorT(Omega);

%%
i  = 1;
Re_tensor{i} = F;
[psnr(i), ssim(i)] = quality_ybz(Y_tensorT*255, Re_tensor{i}*255);
enList = 1;

%% Perform  algorithms
i = i+1;
% initialization of the parameters
% Please refer to our paper to set the parameters
opts=[];
opts.max_R  = [0,  40,  2,  5;
               0,  0,   2,  5;
               0,  0,   0,  2;
               0,  0,   0,  0];
opts.R      = [0,  2,   2,  2;
               0,  0,   2,  2;
               0,  0,   0,  2;
               0,  0,   0,  0];
%     R     = [0,  R_{1,2}, R_{1,3}, ..., R_{1,N};
%              0,     0,    R_{2,3}, ..., R_{2,N};
%              ...
%              0,     0,       0,    ..., R_{N-1,N};
%              0,     0,       0,    ...,   0     ];
opts.tol    = 5*1e-5;
opts.maxit  = 1000;
opts.rho    = 0.1;
opts.lambda = 0.5;
opts.mu     = 1;
opts.Xtrue  = Y_tensorT;
%%%%%
fprintf('\n');
disp(['performing ',methodname{i}, ' ... ']);
t0= tic;
% Please see the difference between 'inc_LRTC_FCTNFR' and 'inc_LRTC_FCTNFR_end' in README.txt.
[Re_tensor{i},G,Out]        = inc_LRTC_FCTNFR(F,Omega,opts);
%[Re_tensor{i},G,Out]        = inc_LRTC_FCTNFR_end(F,Omega,opts);
time(i)                     = toc(t0);
[psnr(i), ssim(i)]          = quality_ybz(Y_tensorT*255, Re_tensor{i}*255);
enList = [enList,i];

%% Show result
fprintf('\n');
fprintf('================== Result =====================\n');
fprintf(' %8.8s    %5.4s    %5.4s    \n','method','PSNR', 'SSIM' );
for i = 1:length(enList)
    fprintf(' %8.8s    %5.3f    %5.3f    \n',...
        methodname{enList(i)},psnr(enList(i)), ssim(enList(i)));
end
fprintf('================== Result =====================\n');

k = 35;
figure,
subplot(1,3,1),imshow(Y_tensorT(:,:,:,k));
subplot(1,3,2),imshow(Re_tensor{1}(:,:,:,k));
subplot(1,3,3),imshow(Re_tensor{2}(:,:,:,k));

