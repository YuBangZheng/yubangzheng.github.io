%  'inc_LRTC_FCTNFR_end.m' supposes that the size of the factor G_k is
%   R_{1,k}*R_{2,k}*...*R_{k-1,k}*R_{k,k+1}*...*R_{k,N}*I_k.
%   can set the initial FCTN rank as 1 in Matlab

function [X, G, Out, U, V] = inc_LRTC_FCTNFR_end(F,Omega,opts)
if isfield(opts, 'tol');         tol       = opts.tol;          end
if isfield(opts, 'maxit');       maxit     = opts.maxit;        end
if isfield(opts, 'rho');         rho       = opts.rho;          end
if isfield(opts, 'R');           R         = opts.R;            end
if isfield(opts, 'lambda');      lambda    = opts.lambda;       end
if isfield(opts, 'mu');          mu        = opts.mu;           end
if isfield(opts, 'max_R');       max_R     = opts.max_R;        end

N = ndims(F);
Nway = size(F);
X = F;

tempdim = R+R';  tempdim(tempdim==0) = [];
tempdim = reshape(tempdim,N-1,N);   tempdim = tempdim';
tempdim(:,end+1) = Nway';

max_tempdim = max_R+max_R';  max_tempdim(max_tempdim==0) = [];
max_tempdim = reshape(max_tempdim,N-1,N);  max_tempdim = max_tempdim';
max_tempdim(:,end+1) = Nway';

R_in = zeros(N,1);
tempdim_in = max_tempdim(:,1:N-1);
for i = 1:N
    R_in(i) = max(tempdim_in(i,:));
end

G = cell(1,N);
U = cell(1,N);
V = cell(1,N);
D = cell(1,N);
Sig2 = cell(1,N);
Unfold_G = cell(1,N);
for i = 1:N
    G{i} = rand(tempdim(i,:));
    U{i} = rand(tempdim(i,end),R_in(i));
    V{i} = rand(R_in(i),prod(tempdim(i,1:end-1)));
    diaga = ones(Nway(i),1);  diagb = ones(Nway(i)-1,1);
    D{i}  = diag(-diaga)+diag(diagb,1);
    D{i}(end,1) = 1;
    d=D{i}(:,1);
    deig=fft(d);
    Sig2{i}=mu*(abs(deig).^2);
end

Out.Res = [];Out.PSNR = [];

r_change = 0.01;

for k = 1:maxit
    Xold = X;
    % Update G
    for i = 1:N
        Xi = my_Unfold(X,Nway,i);
        Unfold_G{i} = my_Unfold(G{i},tempdim(i,:),N);
        Girest = tnreshape_new(tnprod_rest_new(G,i),N);
        tempC = Xi*Girest'+rho*Unfold_G{i}+mu*D{i}'*U{i}*V{i};
        [U1,S1,~] = svd(Girest*Girest');
        Sig1    = diag(S1);
        Sig     = repmat(Sig1',Nway(i),1)+repmat(Sig2{i},1,prod(tempdim(i,:))/Nway(i))+rho;
        Sig     = 1./Sig;
        temp    = Sig.*(fft(tempC)*U1);
        tempG   = real(ifft(temp))*U1';
        G{i}  = my_Fold(tempG,tempdim(i,:),N);
        Unfold_G{i} = my_Unfold(G{i},tempdim(i,:),N);
        U{i} = (mu*D{i}*Unfold_G{i}*V{i}'+rho*U{i})*pinv(mu*V{i}*V{i}'+(lambda+rho)*eye(R_in(i)));
        V{i} = pinv(mu*U{i}'*U{i}+(lambda+rho)*eye(R_in(i)))*(mu*U{i}'*D{i}*Unfold_G{i}+rho*V{i});
    end
    % Update X
    X = (tnprod_new(G)+rho*Xold)/(1+rho);
    X(Omega) = F(Omega);
    
    %% check the convergence
    if isfield(opts, 'Xtrue')
        XT       = opts.Xtrue;
        PSNR     = psnr_ybz(XT*255,X*255);
        Out.PSNR = [Out.PSNR,PSNR];
    end
    res     = norm(X(:)-Xold(:))/norm(Xold(:));
    Out.Res = [Out.Res,res];
    
    if mod(k, 2) == 1
        if isfield(opts, 'Xtrue')
            fprintf('LRTC-FCTNFR: iter = %d   PSNR=%f   res=%f   \n', k, PSNR, res);
        else
            fprintf('LRTC-FCTNFR: iter = %d   res=%f   \n', k, res);
        end
    end
    if res < tol
        break;
    end
    
    rank_inc = double(tempdim<max_tempdim);
    if res < r_change && sum(rank_inc(:)) ~= 0
        [G,V] = rank_inc_adaptive(G,V,rank_inc,R_in,N,tempdim);
        tempdim = tempdim+rank_inc;
    end
end
end

function [G,V]=rank_inc_adaptive(G,V,rank_inc,R_in,N,tempdim)
% increase the estimated rank
for j = 1:N
    G{j} = padarray(G{j},rank_inc(j,:),rand(1),'post');
    tempdim2 = tempdim+rank_inc;
    V{j} = [V{j},zeros(R_in(j),prod(tempdim2(j,1:end-1))-prod(tempdim(j,1:end-1)))];
end
end


    
    

