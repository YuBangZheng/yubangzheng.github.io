********************************************************************************************
    Tensor Completion via Fully-Connected Tensor Network Decomposition 
                                 with Regularized Factors
********************************************************************************************

         Copyright:  Yu-Bang Zheng, Ting-Zhu Huang,  Xi-Le Zhao, 
                                         and Qibin Zhao

Please contact the author to obtain the password.
Email: zhengyubang@163.com 


 
 
 

