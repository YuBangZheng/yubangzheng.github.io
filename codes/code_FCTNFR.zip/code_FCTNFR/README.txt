********************************************************************************************
       Tensor Completion via Fully-Connected Tensor Network Decomposition
                          with Regularized Factors
********************************************************************************************

       Copyright:  Yu-Bang Zheng, Ting-Zhu Huang, Xi-Le Zhao, Qibin Zhao

** Please cite our paper [1] if you use any part of our code **

 1). Get Started

 Run the 'Demo_CV_news' to run the FCTNFR-based TC method.

 2). Details

 A comparison of two main codes: 'inc_LRTC_FCTNFR.m' and 'inc_LRTC_FCTNFR_end.m'
 We suggest to use 'inc_LRTC_FCTNFR_end.m'.

 'inc_LRTC_FCTNFR.m' supposes that the size of the factor G_k is 
  R_{1,k}*R_{2,k}*...*R_{k-1,k}*I_k*R_{k,k+1}*...*R_{k,N}. (consistent with the paper)

 'inc_LRTC_FCTNFR_end.m' supposes that the size of the factor G_k is 
  R_{1,k}*R_{2,k}*...*R_{k-1,k}*R_{k,k+1}*...*R_{k,N}*I_k. (can set the FCTN rank as 1 in Matlab)

 More detail can be found in [1]

    [1] Yu-Bang Zheng, Ting-Zhu Huang*, Xi-Le Zhao*, Qibin Zhao
        Tensor Completion via Fully-Connected Tensor Network Decomposition
        with Regularized Factors, Journal of Scientific Computing��
        vol. 92, no. 8, pp. 1-35, 2022.

 3). Citations

    The data is available at: http://trace.eas.asu.edu/yuv/.


