# code of RBSUTV
********************************************************************************
 Reweighted blocks sparsity regularization for remote sensing images destriping
********************************************************************************

 Copyright:     Jian-Li Wang, Ting-Zhu Huang, Xi-Le Zhao, Jie Huang, Tian-Hui Ma, Yu-Bang Zheng
                   
********************************************************************************
********************************************************************************
  1). Details
  
  More detail can be found in [1]
  

  [1] Reweighted blocks sparsity regularization for remote sensing images destriping,
      Jian-Li Wang, Ting-Zhu Huang, Xi-Le Zhao, Jie Huang, Tian-Hui Ma, Yu-Bang Zheng,
      IEEE J-STARS
********************************************************************************

  2). Please cite our paper if you use any part of our source code.
