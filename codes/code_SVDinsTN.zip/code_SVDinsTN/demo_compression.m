% This demo tests the data representation (compression) ability of SVDinsTN
% Created by Yu-Bang Zheng (zhengyubang@163.com)

clc;
clear;
close all;

addpath(genpath(fullfile(pwd, 'lib')));
addpath(genpath(fullfile(pwd, 'data')));


load('Truck_test.mat')
gama     = 0.0002;
RE_bound = 0.1;
%%%%
fprintf('performing SVDinsTN ...\n');
t0= tic;
[Re_X, G, OutR, CR] = GPU_SVDinsTN(X, gama, RE_bound);
time          = toc(t0);
RE_real       = norm(Re_X(:)-X(:))/norm(X(:));










