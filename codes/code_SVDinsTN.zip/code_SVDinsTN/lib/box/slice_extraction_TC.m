function Out = slice_extraction_TC(X,Omega,N,i,j)
Nway            = size(X);
Omega2          = zeros(Nway);
Omega2(Omega)   = 1;    
a               = [1:N];
a(i)            = [];
a(j-1)          = [];
X               = permute(X,[i,j,a]);
Omega2          = permute(Omega2,[i,j,a]);
NwayX           = size(X);
X               = reshape(X,NwayX(1),NwayX(2),[]);
Omega2          = reshape(Omega2,NwayX(1),NwayX(2),[]);
Out             = sum(X,3);
OutOmega2       = sum(Omega2,3);
OutOmega2(OutOmega2==0) = 1;
Out             = Out./OutOmega2;