%==========================================================================
% Description: This function computes M_k in [1]
% [1] Yu-Bang Zheng, Xi-Le Zhao*, Junhua Zeng, Chao Li, Qibin Zhao,
%     Heng-Chao Li, Ting-Zhu Huang, "SVDinsTN: A Tensor Network Paradigm
%     for Efficient Structure Search from Regularized Modeling Perspective",
%     CVPR, 2024.
% Created by Yu-Bang Zheng （zhengyubang@163.com）
% Jun. 15, 2023

function M = generateM(G,S,k)
N = length(G);
a = [k+1:N, 1:k];
for i = [1:k-1,k+1:N]
    for j = i+1:N
        G{i}      = tensor_contraction_ybz(G{i},diag(S{i,j}),N,2,i+1,1);
    end
    if i > k    
        G{i}      = tensor_contraction_ybz(G{i},diag(S{k,i}),N,2,k,1);
        G{i}      = permute(G{i},[1:k-1,N,k:N-1]);
    end        
    G{i}      = permute(G{i},a);
end     

M    = FCTN_rest_paper(G,a);
M    = permute(M,[2*(N-k)+1:2*(N-1),1:2*(N-k)]);
M    = tnreshape_paper(M,N);


function Out = FCTN_rest_paper(G,a)
N = length(G);
m = 2; n = 1;
Out = G{a(1)};
M = N;
for i = 1:N-2
    Out = tensor_contraction_ybz(Out,G{a(i+1)},M,N,m,n);
    M = M+N-2*i;
    n = [n,1+i];
    tempm = 2+i*(N-i);
    if i>1
        m(2:end)=m(2:end)-[1:i-1];
    end
    m   = [m, tempm];
end


function Out = tnreshape_paper(Grest,N)
Nway = size(Grest);
if  length(Nway) < 2*N-2
    tempNway = ones(1,2*N-2-length(Nway));
    Nway = [Nway,tempNway];
end
m = zeros(N-1,1);   n = zeros(N-1,1);
for k=1:N-1
    m(k) =2*k;n(k)=2*k-1;
end
tempG = permute(Grest,[m,n]);
Out   = reshape(tempG,prod(Nway(m)),prod(Nway(n)));

