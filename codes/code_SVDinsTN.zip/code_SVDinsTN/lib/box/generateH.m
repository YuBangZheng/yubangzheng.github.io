%==========================================================================
% Description: This function computes H_t,l in [1]
% [1] Yu-Bang Zheng, Xi-Le Zhao*, Junhua Zeng, Chao Li, Qibin Zhao,
%     Heng-Chao Li, Ting-Zhu Huang, "SVDinsTN: A Tensor Network Paradigm
%     for Efficient Structure Search from Regularized Modeling Perspective",
%     CVPR, 2024.
% Created by Yu-Bang Zheng （zhengyubang@163.com）
% Jun. 15, 2023

function H = generateH(G,S,t,l)
N = length(G);
dim =1;
for i = 1:N
    dim = dim*size(G{i},i);
end

R = size(S{t,l},1);
for i = [1:t-1,t+1:N-1]
    for j = i+1:N
        G{i}      = tensor_contraction_ybz(G{i},diag(S{i,j}),N,2,i+1,1);
    end
end

for j = t+1:l-1
    G{t}      = tensor_contraction_ybz(G{t},diag(S{t,j}),N,2,t+1,1);
end

for j = l+1:N
    G{t}      = tensor_contraction_ybz(G{t},diag(S{t,j}),N,2,t+2,1);
end

G{t}      = permute(G{t},[1:t,t+2:l,t+1,l+1:N]);

sizeGt    = size(G{t});
sizeGl    = size(G{l});

if length(sizeGt) < N
    sizeGt = [sizeGt, ones(1,N-length(sizeGt))];
end

if length(sizeGl) < N
    sizeGl = [sizeGl, ones(1,N-length(sizeGl))];
end

Gt = my_Unfold(G{t}, sizeGt, l);

Gl = my_Unfold(G{l}, sizeGl, t);

sizeGt(l)=1;
sizeGl(t)=1;

H = zeros(dim, R);

for i = 1: R
    G{t} = my_Fold(Gt(i,:), sizeGt, l);
    G{l} = my_Fold(Gl(i,:), sizeGl, t);
    H_temp = TN_composition(G);
    H(:,i) = H_temp(:);
end

