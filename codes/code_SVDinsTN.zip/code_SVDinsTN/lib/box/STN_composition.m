%==========================================================================
% Description: This function computes the composition of the TN cores
% and diagonal matrices. ($\mathcal{X}= \text{STN}(\mathcal{G},\mathbf{S})$).
% More detail can be found in [1]
% [1] Yu-Bang Zheng, Xi-Le Zhao*, Junhua Zeng, Chao Li, Qibin Zhao,
%     Heng-Chao Li, Ting-Zhu Huang, "SVDinsTN: A Tensor Network Paradigm
%     for Efficient Structure Search from Regularized Modeling Perspective",
%     CVPR, 2024.
% Created by Yu-Bang Zheng （zhengyubang@163.com）
% Jun. 15, 2023

function X = STN_composition(G,S)
N = length(G);
for i = 1:N-1
    for j = i+1:N
        G{i}      = tensor_contraction_ybz(G{i},diag(S{i,j}),N,2,i+1,1);
    end
end
X = TN_composition(G);

