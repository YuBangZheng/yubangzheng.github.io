function Out = slice_extraction(X,N,i,j)
a      = 1:N;
a(i)   =[];
a(j-1) =[];
X      = permute(X,[i,j,a]);
Nway   = size(X);
X      = reshape(X,Nway(1),Nway(2),[]);
Out    = mean(X,3);

