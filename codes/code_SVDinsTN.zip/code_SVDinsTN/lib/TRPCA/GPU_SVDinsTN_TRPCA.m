function [X, Out, OutR] = GPU_SVDinsTN_TRPCA(F,opts)

%% Set default values for optional parameters
gama   = gpuArray(opts.gama);
R        = opts.R;
alpha    = opts.alpha;
eta      = opts.eta;

defaults = {1e-5, 500, 1, 1, 0.001};
[tol, maxit, mu, beta, rho] = defaults{:};
OutR = cell(1,maxit);
N = ndims(F);
Nway = size(F);
X = gpuArray(F);
E = gpuArray.zeros(Nway);

%% Initialization
S = cell(N,N);
for t = 1:N-1
    for l = t+1:N
        temp   = slice_extraction(X,N,t,l);
        S{t,l} = svd(temp);
        S{t,l} = S{t,l}(1:R(t,l));
        S{t,l}    = prox_l1(S{t,l},gama*max(S{t,l}));
        S{t,l}(S{t,l}<eps) = [];
        R(t,l) = length(S{t,l});
    end
end

tempdim = R+R'+diag(Nway);

G = cell(1,N);
for k = 1:N
    G{k} = gpuArray.ones(tempdim(k,:));
    G{k} = G{k}./repmat(sqrt(sum(G{k}.^2,k)),[ones(1,k-1),Nway(k),ones(1,N-k)]);
end

deR = 1;
Out.R = zeros(N,N);
Out.RE = []; Out.PSNR = [];

for step = 1:maxit
    Xold = X;
    if deR > eps
        %% Update G
        for k = 1:N
            Xk = my_Unfold(X,Nway,k);
            Gk = my_Unfold(G{k},tempdim(k,:),k);
            G_without_k = generateM(G,S,k);
            tempC = Xk*G_without_k'+rho*Gk;
            tempA = G_without_k*G_without_k'+(rho+mu)*eye(size(Gk,2));
            G{k}  = my_Fold(tempC*pinv(tempA),tempdim(k,:),k);
        end
        %% Update S and Delete zero elements in S and the corresponding dimensions of G
        for t = 1:N-1
            for l = t+1:N
                H       = generateH(G,S,t,l);
                S{t,l}  = ADMM_S(X(:), H, S{t,l}, gama, beta, rho);
                temp    = find(S{t,l}<eps);
                if ~isempty(temp) && length(temp)<length(S{t,l})
                    S{t,l}(temp) = [];
                    Gt     = my_Unfold(G{t},tempdim(t,:),l);
                    Gl     = my_Unfold(G{l},tempdim(l,:),t);
                    Gt(temp,:)   = [];
                    Gl(temp,:)   = [];
                    tempdim(t,l) = length(S{t,l});
                    tempdim(l,t) = length(S{t,l});
                    G{t}     = my_Fold(Gt,tempdim(t,:),l);
                    G{l}     = my_Fold(Gl,tempdim(l,:),t);
                end
            end
        end

        %% Update E
        tempE = (rho*E+eta*(F-X))/(rho+eta);
        E = prox_l1(tempE,alpha/(rho+eta));
        %% Update X
        X = (STN_composition(G,S)+rho*Xold+eta*(F-E))/(1+rho+eta);

        %% calculate R
        OutR{step} = zeros(N,N);
        for  t = 1:N-1
            for l = t+1:N
                OutR{step}(t,l) = length(S{t,l});
            end
        end
        %% Check if R is updated
        if step > 10
            deR = 0;
            for i = step-9:step
                tempR = OutR{i}-OutR{i-1};
                deR   = deR + norm(tempR(:));
            end
            if deR < eps
                G  = merge(G,S);
            end
        end
    else
        %% merge G and S and only update G and X
        for k = 1:N
            Xk = my_Unfold(X,Nway,k);
            Gk = my_Unfold(G{k},tempdim(k,:),k);
            G_without_k = sub_TN(G,k);
            Gkrest = tnreshape(G_without_k,N,k);
            tempC = Xk*Gkrest'+rho*Gk;
            tempA = Gkrest*Gkrest'+(rho+mu)*eye(size(Gk,2));
            G{k}  = my_Fold(tempC*pinv(tempA),tempdim(k,:),k);
        end
        %% Update E
        tempE = (rho*E+eta*(F-X))/(rho+eta);
        E = prox_l1(tempE,alpha/(rho+eta));
        %% Update X
        X = (TN_composition(G)+rho*Xold+eta*(F-E))/(1+rho+eta);
    end

    %% check the convergence
    if isfield(opts, 'Xtrue')
        XT = gpuArray(opts.Xtrue);
        PSNR = GPU_my_PSNR(255*XT, 255*X);
        Out.PSNR = [Out.PSNR,PSNR];
    end
    RE =norm(X(:)-Xold(:))/norm(Xold(:));
    Out.RE = [Out.RE,RE];

    if step == 1 || mod(step, 5) == 0
        if isfield(opts, 'Xtrue')
            fprintf('SVDinsTN: iter = %d   PSNR = %f   RE = %f  \n', step, PSNR, RE);
        else
            fprintf('SVDinsTN: iter = %d   RE = %f   \n', step, RE);
        end
    end
    if RE < tol
        break;
    end
end
end

function S = ADMM_S(Xs, H, S_old, gama, beta, rho)

Q = S_old;
P = gpuArray.zeros(size(S_old));
tau = gama * max(abs(S_old));

% Precompute H'*Xs and H'*H
Htx = H' * Xs;
Hth = H' * H;
I = gpuArray.eye(size(H,2));
ss = 5;
for s_in = 1:ss
    % Update S
    temp = (beta*Q-P+rho*S_old)/(beta+rho);
    S = prox_l1(temp,tau);
    % Update Q
    tempC = Htx + beta*(S+P/beta);
    tempA = Hth + beta*I;
    Q = pinv(tempA)*tempC;
    % Update P
    P = P + beta*(S-Q);
end
end



function Gnew = merge(G,S)
Gnew = G;
N = length(G);
Snew = cell(N,N);
for i = 1:N-1
    dim_g = size(G{i});
    if length(dim_g) < N
        dim_g = [dim_g,ones(1,N-length(dim_g))];
    end
    for j = i+1:N
        new_dim      = dim_g;
        new_dim(j)   = [];
        Snew{i,j}    = repmat(S{i,j},[1,new_dim]);
        Snew{i,j}    = permute(Snew{i,j}, [circshift(1:j,-1),j+1:N]);
        Gnew{i}      = Gnew{i}.* Snew{i,j};
    end
end
end