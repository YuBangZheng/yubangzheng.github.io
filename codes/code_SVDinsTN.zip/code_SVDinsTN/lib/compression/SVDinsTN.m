function [Re_X, G, OutR, CR] = SVDinsTN(X,gama,RE_bound)

% Set default values for optional parameters
defaults = {1e-5, 1000, 1, 1, 0.001};
[tol, maxit, mu, beta, rho] = defaults{:};
OutputR = cell(1,maxit);
XT = X;
N  = ndims(X);
Nway = size(X);
total_number = prod(Nway);

%% Initialization
S = cell(N,N);
R = zeros(N,N);
for t = 1:N-1
    for l = t+1:N
        S{t,l}   = svd(slice_extraction(X,N,t,l));
        W        = 1./(abs(S{t,l})+eps);
        S{t,l}   = prox_l1(S{t,l},gama*max(S{t,l})*W);
        S{t,l}(S{t,l}<eps) = [];
        R(t,l)   = length(S{t,l});
    end
end

tempdim = R+R'+diag(Nway);

G = cell(1,N);
for k = 1:N
    G{k} = ones(tempdim(k,:));
    G{k} = G{k}./repmat(sqrt(sum(G{k}.^2,k)),[ones(1,k-1),Nway(k),ones(1,N-k)]);
end

deR = 1;
Re_X  = X;

for step = 1:maxit
    Xold = Re_X;
    if deR > eps
        %% Update G
        for k = 1:N
            Xk = my_Unfold(X,Nway,k);
            Gk = my_Unfold(G{k},tempdim(k,:),k);
            G_without_k = generateM(G,S,k);
            tempC = Xk*G_without_k'+rho*Gk;
            tempA = G_without_k*G_without_k'+(rho+mu)*eye(size(Gk,2));
            G{k}  = my_Fold(tempC*pinv(tempA),tempdim(k,:),k);
        end
        %% Update S
        for t = 1:N-1
            for l = t+1:N
                H       = generateH(G,S,t,l);
                S{t,l}  = ADMM_S(X(:), H, S{t,l}, gama, beta, rho, step);
            end
        end
        %% Delete zero elements in S and the corresponding dimensions of G
        for t = 1:N-1
            for l = t+1:N
                temp    = find(S{t,l}<1e-8);
                if ~isempty(temp) && length(temp)<length(S{t,l})
                    S{t,l}(temp) = [];
                    Gt     = my_Unfold(G{t},tempdim(t,:),l);
                    Gl     = my_Unfold(G{l},tempdim(l,:),t);
                    Gt(temp,:)   = [];
                    Gl(temp,:)   = [];
                    tempdim(t,l) = length(S{t,l});
                    tempdim(l,t) = length(S{t,l});
                    G{t}     = my_Fold(Gt,tempdim(t,:),l);
                    G{l}     = my_Fold(Gl,tempdim(l,:),t);
                end
            end
        end

        %% Calculate X
        Re_X = STN_composition(G,S);

        %% Calculate R
        OutputR{step} = zeros(N,N);
        for  t = 1:N-1
            for l = t+1:N
                OutputR{step}(t,l) = length(S{t,l});
            end
        end
        OutR   =  OutputR{step}+OutputR{step}'+diag(Nway);
        CR     =  sum(prod(OutR))/total_number;

        %% Check if R is updated
        if step > 10
            deR = 0;
            for i = step-9:step
                tempR = OutputR{i}-OutputR{i-1};
                deR   = deR + norm(tempR(:));
            end
            if deR < eps
                G = merge(G,S);
                mu = 0;
            end
        end
    else
        %% merge G and S and only update G
        for k = 1:N
            Xk = my_Unfold(X,Nway,k);
            Gk = my_Unfold(G{k},tempdim(k,:),k);
            G_without_k = sub_TN(G,k);
            Gkrest = tnreshape(G_without_k,N,k);
            tempC = Xk*Gkrest'+rho*Gk;
            tempA = Gkrest*Gkrest'+(rho+mu)*eye(size(Gk,2));
            G{k}  = my_Fold(tempC*pinv(tempA),tempdim(k,:),k);
        end
        Re_X = TN_composition(G);
    end

    %% check the convergence
    RE_real     = norm(Re_X(:)-XT(:))/norm(XT(:));
    RE          = norm(Re_X(:)-Xold(:))/norm(Xold(:));
    if step == 1 || mod(step, 20) == 0
            fprintf('SVDinsTN: iter = %d  RE_real = %f  RE = %f  CR = %f  \n', step, RE_real, RE, CR);
    end
    if RE < tol  || RE_real < RE_bound
        break;
    end
end
end

function S = ADMM_S(Xs, H, S_old, gama, beta, rho, it)

Q = S_old;
P = zeros(size(S_old));
tau = gama * max(abs(S_old));

% Precompute quantities that remain unchanged
Htx = H' * Xs;
tempA = H' * H + beta * eye(size(H,2));
tempA_inv = pinv(tempA);

if it < 3
    ss = 1;
else
    ss = 5;
end

for s_in = 1:ss
    % Update S
    temp = (beta*Q-P+rho*S_old)/(beta+rho);
    W = 1./(abs(temp)+eps);
    tau2 = tau*W;
    S = prox_l1(temp,tau2);

    % Update Q
    tempC = Htx + beta*S + P;
    Q = tempA_inv * tempC;

    % Update P
    P = P + beta*(S-Q);
end
end


function Gnew = merge(G,S)
Gnew = G;
N = length(G);
Snew = cell(N,N);
for i = 1:N-1
    dim_g = size(G{i});
    if length(dim_g) < N
        dim_g = [dim_g,ones(1,N-length(dim_g))];
    end
    for j = i+1:N
        new_dim      = dim_g;
        new_dim(j)   = [];
        Snew{i,j}    = repmat(S{i,j},[1,new_dim]);
        Snew{i,j}    = permute(Snew{i,j}, [circshift(1:j,-1),j+1:N]);
        Gnew{i}      = Gnew{i}.* Snew{i,j};
    end
end
end

