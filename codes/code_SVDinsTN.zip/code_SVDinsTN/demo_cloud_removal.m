% This demo tests the performance of SVDinsTN in the MTRSI cloud removal task 
% Created by Yu-Bang Zheng (zhengyubang@163.com)

clear;
clc;
close all;

addpath(genpath(fullfile(pwd, 'lib')));
addpath(genpath(fullfile(pwd, 'data')));

%% Load data
load('testMTRSI.mat');    % Clean: H x W x B x T
load('cloudMask.mat')     % Mask:  H x W x T, where 1 denotes cloud regions
Xtrue = Clean;
Ndim  = ndims(Xtrue);  % 4
Nway  = size(Xtrue);   % H x W x B x T

if Ndim ~= 4
    error('The input Clean should be a 4-D tensor: H x W x B x T.');
end

%% Generate cloud-contaminated observation
% Convert cloud mask to observation mask:
Mask = 1 - Mask; % Omega = 1 for reliable cloud-free pixels, and 0 for cloud-covered pixels.
Mask = repmat(Mask, 1, 1, 1, Nway(3));
Mask = permute(Mask, [1, 2, 4, 3]); % Expand the mask from H x W x T to H x W x B x T.
% Generate the cloud-contaminated tensor.
Cloud_data = Xtrue .* Mask +  (1 - Mask);

%% Set parameters
opts = [];
opts.R = [0, 128, 13, 6;
          0,   0, 13, 6;
          0,   0,  0, 6;
          0,   0,  0, 0];
opts.gama = 0.0006;
opts.Xtrue = Xtrue; % Ground truth, used only for quantitative evaluation

%% Perform SVDinsTN-based cloud removal
fprintf('Performing SVDinsTN...\n');
tStart = tic;
[Re_tensor, ~, OutR] = GPU_SVDinsTN_CLOUD(Cloud_data, Mask, opts);
runTime = toc(tStart);

%% Quantitative evaluation
evalTimeIdx = 1:3;
psnrValue = my_PSNR(255 * Xtrue(:,:,:,evalTimeIdx), ...
                    255 * Re_tensor(:,:,:,evalTimeIdx));
fprintf('PSNR: %.4f dB\n', psnrValue);