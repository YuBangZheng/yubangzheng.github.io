# SVDinsTN MATLAB Code

This repository provides MATLAB demo code for **SVDinsTN**, an SVD-inspired tensor network method for efficient tensor representation and recovery. The current package includes four representative tasks:

1. tensor compression / representation;
2. tensor completion;
3. tensor robust principal component analysis (TRPCA);
4. thick cloud removal for multi-temporal remote sensing images.

The demos are designed to reproduce small-scale examples using the data provided in the `data/` folder.

---

## 1. Folder structure

```text
code_SVDinsTN_tpami/
├── data/
│   ├── Truck_test.mat          # light-field tensor for compression demo
│   ├── color_news_test.mat     # color video tensor for completion and TRPCA demos
│   ├── testMTRSI.mat           # clean MTRSI tensor for cloud removal demo
│   └── cloudMask.mat           # cloud mask for cloud removal demo
│
├── demo_compression.m          # demo for tensor compression / representation
├── demo_completion.m           # demo for tensor completion
├── demo_TRPCA_.m               # demo for TRPCA with sparse noise
├── demo_cloud_removal.m        # demo for MTRSI thick cloud removal
│
├── lib/
│   ├── compression/            # SVDinsTN solvers for tensor compression
│   ├── completion/             # SVDinsTN solvers for tensor completion
│   ├── TRPCA/                  # SVDinsTN solvers for TRPCA
│   ├── cloud removal/          # SVDinsTN solvers for cloud removal
│   └── box/                    # common tensor operations and evaluation tools
│
└── my_normalized.m             # optional normalization utility
```

---

## 2. Requirements

The code was tested in MATLAB-style syntax and requires the following toolboxes for the default GPU demos:

- MATLAB R2020a or later is recommended;
- Parallel Computing Toolbox, for `gpuArray` and GPU acceleration;
- Image Processing Toolbox, for functions such as `imnoise`.

A CUDA-compatible GPU is recommended because all four demo scripts currently call the GPU solvers by default.

If no GPU is available, replace the GPU solver in each demo with the corresponding CPU version. For example:

```matlab
% GPU version
[Re_X, G, OutR, CR] = GPU_SVDinsTN(X, gama, RE_bound);

% CPU version
[Re_X, G, OutR, CR] = SVDinsTN(X, gama, RE_bound);
```

---

## 3. Quick start

Open MATLAB and change the current folder to the root directory of this repository:

```matlab
cd code_SVDinsTN
addpath(genpath(pwd));
```

Then run one of the demo scripts:

```matlab
run demo_compression.m
run demo_completion.m
run demo_TRPCA_.m
run demo_cloud_removal.m
```

Each demo prints the main quantitative result, such as relative error or PSNR.

---

## 4. Demo descriptions

### 4.1 Tensor compression

File:

```matlab
demo_compression.m
```

Purpose:

This demo tests the tensor representation and compression ability of SVDinsTN. It loads a light-field tensor from `Truck_test.mat`, performs SVDinsTN decomposition, reconstructs the tensor, and reports the relative reconstruction error.

Main solver:

```matlab
GPU_SVDinsTN.m
```

Key parameters:

- `gama`: regularization parameter for singular-value shrinkage;
- `RE_bound`: target relative error bound.

---

### 4.2 Tensor completion

File:

```matlab
demo_completion.m
```

Purpose:

This demo evaluates SVDinsTN on randomly sampled tensor completion. It loads a clean color video tensor, randomly keeps a subset of entries, and reconstructs the missing entries using the SVDinsTN-TC model.

Main solver:

```matlab
GPU_SVDinsTN_TC.m
```

Key parameters:

- `sample_ratio`: observed-entry ratio;
- `opts.R`: initial tensor network rank upper bound;
- `opts.gama`: regularization parameter;
- `opts.Xtrue`: ground-truth tensor, used only for evaluation.

---

### 4.3 Tensor robust PCA

File:

```matlab
demo_TRPCA_.m
```

Purpose:

This demo tests SVDinsTN for TRPCA under sparse salt-and-pepper corruption. It loads a clean video tensor, adds sparse noise, and recovers the low-rank tensor component.

Main solver:

```matlab
GPU_SVDinsTN_TRPCA.m
```

Key parameters:

- `rhos`: corruption ratio;
- `opts.R`: initial tensor network rank upper bound;
- `opts.gama`: regularization parameter;
- `opts.alpha`: sparse-noise regularization parameter;
- `opts.eta`: data-fidelity penalty parameter.

---

### 4.4 MTRSI thick cloud removal

File:

```matlab
demo_cloud_removal.m
```

Purpose:

This demo evaluates SVDinsTN for thick cloud removal in multi-temporal remote sensing images. It loads a clean MTRSI tensor and a cloud mask, generates a cloud-contaminated observation, and reconstructs the missing cloud-covered regions.

Main solver:

```matlab
GPU_SVDinsTN_CLOUD.m
```

Key parameters:

- `Mask`: observation mask, where `1` denotes cloud-free observed pixels and `0` denotes cloud-covered missing pixels;
- `opts.R`: initial tensor network rank upper bound;
- `opts.gama`: regularization parameter;
- `opts.Xtrue`: ground-truth tensor, used only for evaluation.

---

## 5. Main functions

| File | Purpose |
|---|---|
| `lib/compression/GPU_SVDinsTN.m` | GPU solver for SVDinsTN tensor compression. |
| `lib/compression/SVDinsTN.m` | CPU solver for SVDinsTN tensor compression. |
| `lib/completion/GPU_SVDinsTN_TC.m` | GPU solver for SVDinsTN tensor completion. |
| `lib/completion/SVDinsTN_TC.m` | CPU solver for SVDinsTN tensor completion. |
| `lib/TRPCA/GPU_SVDinsTN_TRPCA.m` | GPU solver for SVDinsTN-based TRPCA. |
| `lib/TRPCA/SVDinsTN_TRPCA.m` | CPU solver for SVDinsTN-based TRPCA. |
| `lib/cloud removal/GPU_SVDinsTN_CLOUD.m` | GPU solver for SVDinsTN-based cloud removal. |
| `lib/cloud removal/SVDinsTN_CLOUD.m` | CPU solver for SVDinsTN-based cloud removal. |
| `lib/box/*.m` | Shared tensor operations, tensor contraction utilities, folding/unfolding operators, shrinkage operator, and PSNR evaluation. |

---

## 6. Notes

1. The demo scripts use small testing data for convenient reproduction. For larger tensors, memory consumption may increase substantially.
2. The GPU solvers convert major variables to `gpuArray`. Ensure that the GPU has enough memory before running large-scale experiments.
3. The files `opts.Xtrue` and ground-truth tensors are used only for quantitative evaluation and are not required when applying the method to real incomplete data.
4. The folder name `cloud removal` contains a space. MATLAB can still add it through `addpath(genpath(pwd))`, but renaming it to `cloud_removal` is recommended for cleaner open-source maintenance.

---

## 7. Citation

Please cite the corresponding SVDinsTN paper if this code is useful for your research.

[1] Yu-Bang Zheng, Xi-Le Zhao*, Heng-Chao Li*, Junhua Zeng, Chao Li, Qibin Zhao, Ting-Zhu Huang, Qing Zhu, "A Structure-Revealing Tensor Network Paradigm and Its Applications", IEEE Transactions on Pattern Analysis and Machine Intelligence, 2026.
[2] Yu-Bang Zheng, Xi-Le Zhao*, Junhua Zeng, Chao Li, Qibin Zhao, Heng-Chao Li, Ting-Zhu Huang, "SVDinsTN: A Tensor Network Paradigm for Efficient Structure Search from Regularized Modeling Perspective", Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR), 2024.


