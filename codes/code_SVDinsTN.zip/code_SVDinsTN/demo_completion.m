% This demo tests the performance of SVDinsTN in the tensor completion task 
% Created by Yu-Bang Zheng (zhengyubang@163.com)

clc;
clear;
close all;

addpath(genpath(fullfile(pwd, 'lib')));
addpath(genpath(fullfile(pwd, 'data')));


%% Load initial data
load('color_news_test.mat')

%% Sampling with random position
sample_ratio = 0.10;
fprintf('=== The sample ratio is %4.2f ===\n', sample_ratio);
Y_tensorT = X;
Ndim      = ndims(Y_tensorT);
Nway      = size(Y_tensorT);
rand('seed',2);
Omega     = find(rand(prod(Nway),1)<sample_ratio);
Y_tensor0 = zeros(Nway);
Y_tensor0(Omega) = Y_tensorT(Omega);

%% performing SVDinsTN-TC
opts=[];
opts.R   = [0,  60   3,  25;
            0,  0,   3,  25;
            0,  0,   0,   3;
            0,  0,   0,  0]; 
opts.gama   = 0.0004;
opts.Xtrue  = Y_tensorT;
%%%%
fprintf('Performing SVDinsTN...\n');
t0= tic;
[Re_tensor,Out,OutR] = GPU_SVDinsTN_TC(Y_tensor0,Omega,opts);
time       = toc(t0);
psnr       = my_PSNR(Y_tensorT*255, Re_tensor*255);
fprintf('PSNR: %.4f dB\n', psnr);

