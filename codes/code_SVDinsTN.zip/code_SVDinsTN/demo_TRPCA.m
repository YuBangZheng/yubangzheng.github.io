% This demo tests the performance of SVDinsTN in the TRPCA task
% Created by Yu-Bang Zheng (zhengyubang@163.com)

clc;
clear;
close all;

addpath(genpath(fullfile(pwd, 'lib')));
addpath(genpath(fullfile(pwd, 'data')));

rng(6, 'twister');
%% Load data
load('color_news_test.mat');

%% Generate corrupted observations
% rhos controls the ratio of corrupted pixels.
rhos = 0.4;
fprintf('=== Corruption ratio: %.2f ===\n', rhos);

% Add salt-and-pepper noise to the clean tensor.
Noise_tensor = imnoise(X, 'salt & pepper', rhos);
Nway = size(Noise_tensor);

%% Set parameters
opts = [];
opts.R = [0, 60, 3, 25;
          0,  0, 3, 25;
          0,  0, 0,  3;
          0,  0, 0,  0];
opts.gama = 0.00065;
opts.alpha = 0.01;
opts.eta   = 1;
opts.Xtrue = X;% Ground truth, used only for quantitative evaluation

%% Run SVDinsTN for TRPCA
fprintf('Performing SVDinsTN...\n');
tStart = tic;
[Re_tensor, ~, OutR] = GPU_SVDinsTN_TRPCA(Noise_tensor, opts);
runTime = toc(tStart);

%% Quantitative evaluation
psnr_value = my_PSNR(255 * X, 255 * Re_tensor);
fprintf('PSNR: %.4f dB\n', psnr_value);
