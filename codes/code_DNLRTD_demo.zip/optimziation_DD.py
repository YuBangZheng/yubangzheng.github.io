'''
Written by Zhi-Wei Shi. E-mail: zhiweishi@foxmai.com.
More details can be found in the following paper:
"Multidimensional Image Reconstruction via Deep Nonlinear Low-Rank Tensor Decomposition," in IEEE TCSVT, 2026.
IF you find this code useful, please cite our paper.
'''

import torch
from func import *
from model.transform_loader import *
import scipy.io as sio
from model.utils import MSIQA
import warnings

warnings.filterwarnings('ignore')
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')


def ADMM_Iter_DD(meas, Phi, data_truth, args, result_dir):

    #-------------- Initialization --------------#
    best_PSNR = 0
    x0 = At(meas, Phi)
    Phi_sum = torch.sum(Phi**2, 2)
    Phi_sum[Phi_sum == 0] = 1
    theta = x0.to(device)
    b = torch.zeros_like(x0).to(device)
    mu, rank, data_name = args.mu, args.rank, args.name
    iter_num, LR_iter, R_iter, WS_iter = args.iter_num, args.LR_iter,args.R_iter, args.WS_iter

    # ---------------- Iteration ----------------#
    for iter in range(iter_num):
        c = theta.to(device) + b.to(device)
        meas_b = A(c, Phi)
        x = c + At((meas - meas_b) / (Phi_sum + mu), Phi)
        x1 = x - b
        
        if iter < WS_iter:
            theta = TV_minimization(x1, 90, 10)
        else:
            theta = DNLRTD_PnP(data_truth, x1, meas, Phi, LR_iter, R_iter, rank, data_name)

        # --------------- Evaluation ---------------#
        psnr_x, ssim_x, _ = MSIQA(data_truth.permute(2, 0, 1).cpu().numpy(), theta.permute(2, 0, 1).cpu().numpy())
        print('ADMM_Iter {} | PSNR = {:.3f}dB | SSIM = {:.3f}'.format( iter, psnr_x, ssim_x))
        
        if psnr_x > best_PSNR and iter > WS_iter:
            sio.savemat(result_dir + '/Iter-{}-Rank={}-PSNR-{:2.2f}.mat'.format(iter, rank, psnr_x), {'img':theta.cpu().numpy()})
            best_PSNR = psnr_x
        
        b = b - (x.to(device) - theta.to(device))
        
    return theta 

    
def DNLRTD_PnP(data_truth, temp_theta, meas, Phi, LR_iter, R_iter, rank, data_name):
    best_loss = float('inf')
    reg_noise_std = 1.0/30.0
    H, W, B = data_truth.shape
    loss_fn = torch.nn.L1Loss().to(device)
    loss_l2 = torch.nn.MSELoss().to(device)
    DNTN = transform_network_load(B)

    if os.path.exists('Results/' + data_name + '/' + 'model_weights.pth'):
        loadname = 'Results/' + data_name + '/' + 'model_weights.pth'
        DNTN[0].load_state_dict(torch.load(loadname)['DNTN'])
        LR_iter = R_iter
        print('----------------- Loading DNLRTD weights Training -----------------')
    else:
        print('----------------------- DNLRTD Pre-training -----------------------')
    
    truth_tensor = data_truth.permute(2, 0, 1).unsqueeze(0).to(device)
    temp_theta = temp_theta.permute(2, 0, 1).unsqueeze(0).to(device) 
    
    # Latent factor initialization
    factor_A = get_input([1, H, W, rank]).to(device)
    factor_B = get_input([1, H, rank, B]).to(device)


    DNTN[0].train()

    net_params = list(DNTN[0].parameters())
    input_params = [factor_A] + [factor_B]
    factor_A_temp = factor_A.detach().clone()
    factor_B_temp = factor_B.detach().clone()
    params = net_params + input_params

    optimizer = torch.optim.Adam(params=params, lr=0.001)
    
    for idx in range(LR_iter):
        factor_A_perturbed = factor_A + factor_A_temp.normal_()*reg_noise_std
        factor_B_perturbed = factor_B + factor_B_temp.normal_()*reg_noise_std

        input = torch.matmul(factor_A_perturbed, factor_B_perturbed).permute(0,3,2,1)

        model_out = DNTN[0](input)

        loss = loss_fn(meas, A(model_out.squeeze(0).permute(1, 2, 0).to(device), Phi.to(device)))
        loss += loss_l2(temp_theta.float().to(device), model_out.float().to(device))
        
        optimizer.zero_grad()   
        loss.backward()
        optimizer.step()
        
        if loss.item() < best_loss:
            best_loss = loss.item()
            best_hs_recon = model_out.detach()
            savenaem = 'Results/' + data_name + '/' + 'model_weights.pth'
            torch.save({'DNTN': DNTN[0].state_dict()}, savenaem)
        
        if (idx+1)%100==0:
            PSNR = calculate_psnr(truth_tensor, model_out.squeeze(0))
            print('DNLRTD_Iter {}, x_loss:{:.4f}, PSNR:{:.2f}'.format(idx+1, loss.detach().cpu().numpy(), PSNR))
        
    return best_hs_recon.squeeze(0).permute(1, 2, 0)
