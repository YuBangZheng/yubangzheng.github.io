import torch
import os
from collections import OrderedDict
from model.DNTNet import Deep_nonlinear_transform_Network

device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')

def transform_network_load(bands):
    DNTN = Deep_nonlinear_transform_Network(bands, 'skip', 'reflection',
                            upsample_mode= 'bilinear',
                            skip_n33d=64,
                            skip_n33u=64,
                            #skip_n11=16,
                            skip_n11=0,
                            num_scales=3,
                            n_channels=bands).to(device)   

    return [DNTN]
      
def get_input(tensize, const=10.0):
    inp = torch.rand(tensize)/const
    inp = torch.autograd.Variable(inp, requires_grad=True).to(device)
    inp = torch.nn.Parameter(inp).float()
    return inp
