
'''
Written by Zhi-Wei Shi. E-mail: zhiweishi@foxmai.com.
More details can be found in the following paper:
"Multidimensional Image Reconstruction via Deep Nonlinear Low-Rank Tensor Decomposition," IEEE TCSVT, 2026.
IF you find this paper and code useful, please cite our paper.
The demo data, MSI toys, physical masks, and pre-trained weights can be found in this link: https://pan.quark.cn/s/f19e1749e816
Place the data and masks in the "Data " folder, and the pre-trained weights in the "Results\toys" folder.
It takes time to achieve the best results.
We recommend running the code multiple times and selecting the best result.
'''

import os
os.environ["KMP_DUPLICATE_LIB_OK"]  =  "TRUE"
import torch
import argparse
from func import *
from numpy import *
import scipy.io as sio
from optimziation_DD import ADMM_Iter_DD
import warnings

warnings.filterwarnings('ignore')
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
random.seed(3)

#Data Configuration
parser = argparse.ArgumentParser()
parser.add_argument( '--name',     default = 'toys',         help = "Data name" )
parser.add_argument( '--iter_num', default = 320,            help = "Iterations number of ADMM, iter_num > wS_iter" )
parser.add_argument( '--LR_iter',  default = 5000,           help = "Training epochs of deep DNLRTD" )
parser.add_argument( '--R_iter',   default = 2000,           help = "Training epochs after loading DNLRTD weights" )
parser.add_argument( '--WS_iter',  default = 3,            help = "Iterations number of warm start" )
parser.add_argument( '--mu',       default = 0.001,          help = "Penalty parameter of ADMM" )
parser.add_argument( '--rank',     default = 20,             help = "Rank of DNLRTD" )

args = parser.parse_args()

dataset_dir = './Data/'
mask_name = 'dd_mask512'
data_name =  args.name

results_dir = './Results/' + data_name + '/'
if not os.path.exists(results_dir):
    os.makedirs(results_dir)
    
datamatfile = dataset_dir + '/' + data_name + '.mat'
maskmatfile = dataset_dir + '/' + mask_name + '.mat'

data_truth = torch.from_numpy(sio.loadmat(datamatfile)['img']).to(device)
Phi = torch.from_numpy(sio.loadmat(maskmatfile)['mask']).to(device)
meas = torch.sum(Phi * data_truth, 2).to(device)

# ADMM Optimization
recon = ADMM_Iter_DD(meas, Phi, data_truth, args, results_dir)

