"""Demo for SVDinsTN multitemporal remote-sensing cloud removal."""

from pathlib import Path
import time

import numpy as np
import torch
from scipy.io import loadmat

from svdinstn.svdinstn_cloud_removal import svdinstn_cloud


def main():
    # Load the clean tensor and cloud mask.
    data_dir = Path("data")
    Xtrue_np = np.asarray(
        loadmat(data_dir / "testMTRSI.mat")["Clean"],
        dtype=np.float64,
    )
    cloud_mask_np = np.asarray(
        loadmat(data_dir / "cloudMask.mat")["Mask"],
        dtype=np.float64,
    )

    H, W, B, T = Xtrue_np.shape

    # Prepare the data on the GPU.
    device = torch.device("cuda")
    Xtrue = torch.as_tensor(
        Xtrue_np, dtype=torch.float64, device=device
    )
    cloud_mask = torch.as_tensor(
        cloud_mask_np, dtype=torch.float64, device=device
    )

    # Construct the observation mask and cloud-contaminated tensor.
    observation_mask = (
        (1.0 - cloud_mask)
        .unsqueeze(2)
        .expand(H, W, B, T)
        .contiguous()
    )
    Cloud_data = Xtrue * observation_mask + (1.0 - observation_mask)

    # Set the parameters.
    opts = {
        "R": np.array([
            [0, 128, 13, 6],
            [0,   0, 13, 6],
            [0,   0,  0, 6],
            [0,   0,  0, 0],
        ], dtype=np.int64),
        "gama": 0.0004,
        "Xtrue": Xtrue,
    }

    print(f"Device: {device}")
    print(f"Tensor shape: {Xtrue_np.shape}")
    print("Performing SVDinsTN cloud removal...")

    # Run the algorithm and measure the elapsed time.
    torch.cuda.synchronize()
    start = time.perf_counter()

    Re_tensor, Out, OutR = svdinstn_cloud(
        Cloud_data,
        observation_mask > 0.5,
        opts,device=device, verbose=True
    )

    torch.cuda.synchronize()
    elapsed = time.perf_counter() - start

    # Evaluate mean slice-wise PSNR over the first three time frames.
    eval_T = min(3, T)
    psnr_value = svdinstn_cloud_psnr(
        255.0 * Xtrue[:, :, :, :eval_T],
        255.0 * Re_tensor[:, :, :, :eval_T],
    )

    print(f"PSNR: {psnr_value.item():.4f} dB")
    print(f"Elapsed time: {elapsed:.2f} s")
    print(f"Iterations: {len(Out['RE'])}")

def svdinstn_cloud_psnr(reference, estimate):
    """Compute mean slice-wise PSNR for H x W x B x T tensors."""
    ref = reference.permute(2, 3, 0, 1).reshape(
        -1, reference.shape[0], reference.shape[1]
    )
    est = estimate.permute(2, 3, 0, 1).reshape(
        -1, estimate.shape[0], estimate.shape[1]
    )

    mse = (ref - est).square().mean(dim=(1, 2))
    values = 10.0 * torch.log10(
        (255.0 ** 2) / mse.clamp_min(torch.finfo(mse.dtype).tiny)
    )
    values = torch.where(
        mse == 0, torch.full_like(values, float("inf")), values
    )

    return values.mean()


if __name__ == "__main__":
    main()
