"""PyTorch implementation of SVDinsTN for tensor completion."""

import torch

from svdinstn.my_psnr import my_psnr
from svdinstn.torch_ops import (
    my_unfold, my_fold, prox_l1, generate_m, generate_h,
    stn_composition, sub_tn, tnreshape, tn_composition, flatten_f,
)


def slice_extraction_tc(X, Omega, i, j):
    """Compute pairwise mode statistics from observed entries."""
    if X.ndim < 2:
        raise ValueError("X must have at least two dimensions")
    if X.shape != Omega.shape:
        raise ValueError("X and Omega must have the same shape")

    other_modes = [k for k in range(X.ndim) if k not in (i, j)]
    perm = [i, j] + other_modes

    Xp = X.permute(perm).reshape(X.shape[i], X.shape[j], -1)
    Mp = Omega.permute(perm).reshape(X.shape[i], X.shape[j], -1)

    numerator = (Xp * Mp).sum(dim=2)
    denominator = Mp.sum(dim=2).to(X.dtype).clamp_min(1)

    return numerator / denominator


def _admm_s(x_vec, H, S_old, gama, beta=1.0, rho=0.001):
    """Update connection weights using ADMM."""
    Q = S_old.clone()
    P = torch.zeros_like(S_old)
    tau = gama * S_old.abs().max()

    Ht = H.T
    Htx = Ht @ x_vec
    tempA = Ht @ H + beta * torch.eye(
        H.shape[1], dtype=H.dtype, device=H.device
    )
    tempA_pinv = torch.linalg.pinv(tempA, hermitian=True)

    for _ in range(5):
        temp = (beta * Q - P + rho * S_old) / (beta + rho)
        W = 1.0 / (temp.abs() + torch.finfo(temp.dtype).eps)
        S = prox_l1(temp, tau * W)
        tempC = Htx + beta * S + P
        Q = tempA_pinv @ tempC
        P = P + beta * (S - Q)

    return S.reshape(-1)


def _merge(G, S):
    """Absorb connection weights into the tensor network factors."""
    Gnew = [g.clone() for g in G]
    N = len(G)

    for i in range(N - 1):
        for j in range(i + 1, N):
            if S[i][j] is not None:
                shape = [1] * N
                shape[j] = S[i][j].numel()
                Gnew[i] = Gnew[i] * S[i][j].reshape(shape)

    return Gnew


def svdinstn_tc(
    F,
    Omega,
    opts,
    tol=1e-5,
    maxit=500,
    mu=1.0,
    beta=1.0,
    rho=0.001,
    verbose=True,
    device=None,
):
    """Perform tensor completion using SVDinsTN."""

    device = torch.device(
        device if device is not None else
        ("cuda" if torch.cuda.is_available() else "cpu")
    )

    F = torch.as_tensor(F, dtype=torch.float64, device=device)
    Omega = torch.as_tensor(Omega, dtype=torch.bool, device=device)

    if F.shape != Omega.shape:
        raise ValueError("F and Omega must have the same shape")

    X = F.clone()
    gama = torch.as_tensor(opts["gama"], dtype=F.dtype, device=device)
    R = torch.as_tensor(
        opts["R"], dtype=torch.int64, device=device
    ).clone()

    N = F.ndim
    Nway = list(F.shape)
    eps = torch.finfo(F.dtype).eps

    # Initialize connection weights from observed-entry statistics.
    S = [[None for _ in range(N)] for _ in range(N)]

    for t in range(N - 1):
        for l in range(t + 1, N):
            temp = slice_extraction_tc(X, Omega, t, l)
            sv = torch.linalg.svdvals(temp)
            sv = sv[:min(int(R[t, l].item()), sv.numel())]

            if sv.numel() > 0:
                W = 1.0 / (sv.abs() + eps)
                sv = prox_l1(sv, gama * sv.max() * W)
                sv = sv[sv >= eps]

            S[t][l] = sv
            R[t, l] = sv.numel()

    # Initialize normalized tensor network factors.
    tempdim = R + R.T + torch.diag(
        torch.tensor(Nway, dtype=R.dtype, device=device)
    )

    G = []
    for k in range(N):
        g = torch.ones(
            tuple(int(v) for v in tempdim[k].tolist()),
            dtype=F.dtype,
            device=device,
        )
        G.append(g / torch.sqrt(g.pow(2).sum(dim=k, keepdim=True)))

    deR = 1.0
    Out = {
        "R": torch.zeros((N, N), dtype=torch.int64, device=device),
        "RE": [],
        "PSNR": [],
    }
    OutR = [None] * maxit

    Xtrue = opts.get("Xtrue")
    if Xtrue is not None:
        Xtrue = torch.as_tensor(
            Xtrue, dtype=F.dtype, device=device
        )

    # Main optimization loop.
    for step in range(1, maxit + 1):
        Xold = X.clone()

        if deR > eps:
            # Update tensor network factors.
            for k in range(N):
                dim_k = [int(v) for v in tempdim[k].tolist()]
                Xk = my_unfold(X, Nway, k)
                Gk = my_unfold(G[k], dim_k, k)
                M = generate_m(G, S, k)

                tempC = Xk @ M.T + rho * Gk
                tempA = M @ M.T + (rho + mu) * torch.eye(
                    Gk.shape[1], dtype=F.dtype, device=device
                )

                G[k] = my_fold(
                    tempC @ torch.linalg.pinv(tempA, hermitian=True),
                    dim_k,
                    k,
                )

            # Match MATLAB's column-major vectorization.
            x_vec = flatten_f(X)

            # Update connection weights and prune small ranks.
            for t in range(N - 1):
                for l in range(t + 1, N):
                    H = generate_h(G, S, t, l)
                    S[t][l] = _admm_s(
                        x_vec, H, S[t][l], gama, beta, rho
                    )

                    keep = S[t][l] >= eps
                    if bool(torch.any(~keep).item()) and bool(
                        torch.any(keep).item()
                    ):
                        S[t][l] = S[t][l][keep]

                        dim_t = [int(v) for v in tempdim[t].tolist()]
                        dim_l = [int(v) for v in tempdim[l].tolist()]

                        Gt = my_unfold(G[t], dim_t, l)[keep, :]
                        Gl = my_unfold(G[l], dim_l, t)[keep, :]

                        rank = S[t][l].numel()
                        tempdim[t, l] = rank
                        tempdim[l, t] = rank
                        dim_t[l] = rank
                        dim_l[t] = rank

                        G[t] = my_fold(Gt, dim_t, l)
                        G[l] = my_fold(Gl, dim_l, t)

            # Reconstruct the tensor and restore observed entries.
            X = (stn_composition(G, S) + rho * Xold) / (1.0 + rho)
            X = torch.where(Omega, F, X)

            # Record the current rank matrix.
            out_r = torch.zeros(
                (N, N), dtype=torch.int64, device=device
            )
            for t in range(N - 1):
                for l in range(t + 1, N):
                    out_r[t, l] = S[t][l].numel()

            OutR[step - 1] = out_r.detach()
            Out["R"] = out_r.detach()

            # Detect rank stabilization.
            if step > 10:
                deR_tensor = torch.zeros(
                    (), dtype=F.dtype, device=device
                )
                for i in range(step - 10, step):
                    diff = OutR[i] - OutR[i - 1]
                    deR_tensor += torch.linalg.vector_norm(
                        diff.to(F.dtype)
                    )

                deR = deR_tensor.item()
                if deR < eps:
                    G = _merge(G, S)

        else:
            # Update factors after rank stabilization.
            for k in range(N):
                dim_k = [int(v) for v in tempdim[k].tolist()]
                Xk = my_unfold(X, Nway, k)
                Gk = my_unfold(G[k], dim_k, k)
                Grest = tnreshape(sub_tn(G, k), N, k)

                tempC = Xk @ Grest.T + rho * Gk
                tempA = Grest @ Grest.T + (rho + mu) * torch.eye(
                    Gk.shape[1], dtype=F.dtype, device=device
                )

                G[k] = my_fold(
                    tempC @ torch.linalg.pinv(tempA, hermitian=True),
                    dim_k,
                    k,
                )

            X = (tn_composition(G) + rho * Xold) / (1.0 + rho)
            X = torch.where(Omega, F, X)

        # Evaluate convergence and reconstruction quality.
        RE = (
            torch.linalg.vector_norm(X - Xold)
            / torch.linalg.vector_norm(Xold).clamp_min(eps)
        )
        Out["RE"].append(RE)

        if Xtrue is not None:
            Out["PSNR"].append(my_psnr(255.0 * Xtrue, 255.0 * X))

        if verbose and (step == 1 or step % 5 == 0):
            msg = f"SVDinsTN-TC: iter={step} RE={RE.item():.6g}"
            if Xtrue is not None:
                msg += f" PSNR={Out['PSNR'][-1].item():.6f}"
            print(msg)

        if RE.item() < tol:
            break

    return X, Out, OutR[:step]
