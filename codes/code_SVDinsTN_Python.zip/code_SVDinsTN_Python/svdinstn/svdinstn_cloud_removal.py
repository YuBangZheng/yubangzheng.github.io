"""PyTorch implementation of SVDinsTN for multitemporal cloud removal."""

import torch

from svdinstn.torch_ops import (
    my_unfold, my_fold, prox_l1, generate_m, generate_h,
    stn_composition, sub_tn, tnreshape, tn_composition,
)


def _observed_slice_average(X, mask, i, j):
    """Compute pairwise-mode averages from observed entries."""
    n = X.ndim
    other_modes = [k for k in range(n) if k not in (i, j)]
    perm = [i, j] + other_modes

    Xp = X.permute(perm).reshape(X.shape[i], X.shape[j], -1)
    Mp = mask.permute(perm).reshape(mask.shape[i], mask.shape[j], -1)

    numerator = (Xp * Mp).sum(dim=2)
    denominator = Mp.sum(dim=2).to(X.dtype).clamp_min(1.0)

    return numerator / denominator


def _admm_s_cloud(x_vec, H, S_old, gama, beta=1.0, rho=0.001):
    """Update connection weights using ADMM."""
    Q = S_old.clone()
    P = torch.zeros_like(S_old)
    tau = gama * S_old.abs().max()

    Ht = H.T
    Htx = Ht @ x_vec
    tempA = Ht @ H + beta * torch.eye(
        H.shape[1], dtype=H.dtype, device=H.device
    )
    tempA_inv = torch.linalg.pinv(tempA, hermitian=True)

    for _ in range(5):
        temp = (beta * Q - P + rho * S_old) / (beta + rho)
        S = prox_l1(temp, tau)
        tempC = Htx + beta * (S + P / beta)
        Q = tempA_inv @ tempC
        P = P + beta * (S - Q)

    return S.reshape(-1)


def _merge_cloud(G, S):
    """Absorb connection weights into the tensor network factors."""
    Gnew = [g.clone() for g in G]
    n = len(G)

    for i in range(n - 1):
        for j in range(i + 1, n):
            if S[i][j] is not None:
                shape = [1] * n
                shape[j] = S[i][j].numel()
                Gnew[i] = Gnew[i] * S[i][j].reshape(shape)

    return Gnew


def svdinstn_cloud(
    F, Mask, opts, tol=1e-5, maxit=500, mu=1.0,
    beta=1.0, rho=0.001, verbose=True, device=None
):
    """Perform multitemporal remote-sensing cloud removal."""

    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
    device = torch.device(device)

    F = torch.as_tensor(F, dtype=torch.float64, device=device)
    Mask = torch.as_tensor(Mask, dtype=torch.bool, device=device)

    if F.ndim != 4:
        raise ValueError(
            f"F must be a 4-D tensor (H,W,B,T), got {tuple(F.shape)}"
        )
    if F.shape != Mask.shape:
        raise ValueError("F and Mask must have the same shape")

    n = F.ndim
    Nway = list(F.shape)
    eps = torch.finfo(F.dtype).eps
    gama = torch.as_tensor(opts["gama"], dtype=F.dtype, device=device)
    R = torch.as_tensor(
        opts["R"], dtype=torch.int64, device=device
    ).clone()

    # Initialize cloudy pixels using the temporal mean.
    tempY = F * Mask
    tempX = tempY.sum(dim=3, keepdim=True) / (
        Mask.sum(dim=3, keepdim=True).to(F.dtype) + 1e-11
    )
    X = tempY + tempX.expand_as(tempY) * (~Mask).to(F.dtype)

    # Initialize connection weights using pairwise-mode SVDs.
    S = [[None for _ in range(n)] for _ in range(n)]

    for t in range(n - 1):
        for l in range(t + 1, n):
            pair_matrix = _observed_slice_average(X, Mask, t, l)
            singular_values = torch.linalg.svdvals(pair_matrix)
            rank = min(int(R[t, l].item()), singular_values.numel())
            singular_values = singular_values[:rank]

            if singular_values.numel() > 0:
                singular_values = prox_l1(
                    singular_values, gama * singular_values.max()
                )
                singular_values = singular_values[singular_values >= eps]

            S[t][l] = singular_values
            R[t, l] = singular_values.numel()

    # Initialize normalized tensor network factors.
    tempdim = R + R.T + torch.diag(
        torch.tensor(Nway, dtype=R.dtype, device=device)
    )

    G = []
    for k in range(n):
        shape = tuple(int(v) for v in tempdim[k].tolist())
        g = torch.ones(shape, dtype=F.dtype, device=device)
        G.append(g / torch.sqrt(g.square().sum(dim=k, keepdim=True)))

    deR = 1.0
    Out = {
        "R": torch.zeros((n, n), dtype=torch.int64, device=device),
        "RE": [],
        "PSNR": [],
    }
    OutR = [None] * maxit

    Xtrue = opts.get("Xtrue")
    if Xtrue is not None:
        Xtrue = torch.as_tensor(
            Xtrue, dtype=F.dtype, device=device
        )

    # Main optimization loop.
    for step in range(1, maxit + 1):
        Xold = X.clone()

        if deR > eps:
            # Update tensor network factors.
            for k in range(n):
                dim_k = [int(v) for v in tempdim[k].tolist()]
                Xk = my_unfold(X, Nway, k)
                Gk = my_unfold(G[k], dim_k, k)
                G_without_k = generate_m(G, S, k)

                tempC = Xk @ G_without_k.T + rho * Gk
                tempA = G_without_k @ G_without_k.T + (
                    rho + mu
                ) * torch.eye(
                    Gk.shape[1], dtype=F.dtype, device=device
                )

                G[k] = my_fold(
                    tempC @ torch.linalg.pinv(
                        tempA, hermitian=True
                    ),
                    dim_k, k
                )

            # Update connection weights and prune small ranks.
            x_vec = X.permute(
                *reversed(range(X.ndim))
            ).contiguous().reshape(-1)

            for t in range(n - 1):
                for l in range(t + 1, n):
                    H = generate_h(G, S, t, l)
                    S[t][l] = _admm_s_cloud(
                        x_vec, H, S[t][l], gama, beta, rho
                    )

                    keep = S[t][l] >= eps
                    if bool(torch.any(~keep).item()) and bool(
                        torch.any(keep).item()
                    ):
                        S[t][l] = S[t][l][keep]

                        dim_t = [int(v) for v in tempdim[t].tolist()]
                        dim_l = [int(v) for v in tempdim[l].tolist()]

                        Gt = my_unfold(G[t], dim_t, l)[keep, :]
                        Gl = my_unfold(G[l], dim_l, t)[keep, :]

                        rank = S[t][l].numel()
                        tempdim[t, l] = rank
                        tempdim[l, t] = rank
                        dim_t[l] = rank
                        dim_l[t] = rank

                        G[t] = my_fold(Gt, dim_t, l)
                        G[l] = my_fold(Gl, dim_l, t)

            # Update the reconstruction and restore clear observations.
            X = (stn_composition(G, S) + rho * Xold) / (1.0 + rho)
            X = torch.where(Mask, F, X)

            # Record the current rank matrix.
            rank_matrix = torch.zeros(
                (n, n), dtype=torch.int64, device=device
            )
            for t in range(n - 1):
                for l in range(t + 1, n):
                    rank_matrix[t, l] = S[t][l].numel()

            OutR[step - 1] = rank_matrix.detach().clone()
            Out["R"] = rank_matrix.detach().clone()

            # Check rank stability.
            if step > 10:
                deR_tensor = torch.zeros(
                    (), dtype=F.dtype, device=device
                )
                for i in range(step - 10, step):
                    deR_tensor += torch.linalg.vector_norm(
                        (OutR[i] - OutR[i - 1]).to(F.dtype)
                    )

                deR = deR_tensor.item()
                if deR < eps:
                    G = _merge_cloud(G, S)

        else:
            # Update factors after rank stabilization.
            for k in range(n):
                dim_k = [int(v) for v in tempdim[k].tolist()]
                Xk = my_unfold(X, Nway, k)
                Gk = my_unfold(G[k], dim_k, k)
                G_without_k = sub_tn(G, k)
                Gkrest = tnreshape(G_without_k, n, k)

                tempC = Xk @ Gkrest.T + rho * Gk
                tempA = Gkrest @ Gkrest.T + (
                    rho + mu
                ) * torch.eye(
                    Gk.shape[1], dtype=F.dtype, device=device
                )

                G[k] = my_fold(
                    tempC @ torch.linalg.pinv(
                        tempA, hermitian=True
                    ),
                    dim_k, k
                )

            X = (tn_composition(G) + rho * Xold) / (1.0 + rho)
            X = torch.where(Mask, F, X)

        # Evaluate convergence and reconstruction quality.
        RE = torch.linalg.vector_norm(X - Xold) / (
            torch.linalg.vector_norm(Xold).clamp_min(eps)
        )
        Out["RE"].append(RE)

        if Xtrue is not None:
            eval_T = min(3, X.shape[3])
            psnr = _slice_mean_psnr(
                255.0 * Xtrue[:, :, :, :eval_T],
                255.0 * X[:, :, :, :eval_T],
            )
            Out["PSNR"].append(psnr)

        if verbose and (step == 1 or step % 5 == 0):
            message = (
                f"SVDinsTN-CLOUD: iter={step} "
                f"RE={RE.item():.6g}"
            )
            if Xtrue is not None:
                message += f" PSNR={Out['PSNR'][-1].item():.6f}"
            print(message)

        if RE.item() < tol:
            break

    return X, Out, OutR[:step]


def _slice_mean_psnr(reference, estimate):
    """Compute mean PSNR over spatial slices."""
    ref = reference.permute(2, 3, 0, 1).reshape(
        -1, reference.shape[0], reference.shape[1]
    )
    est = estimate.permute(2, 3, 0, 1).reshape(
        -1, estimate.shape[0], estimate.shape[1]
    )

    mse = (ref - est).square().mean(dim=(1, 2))
    psnr = 10.0 * torch.log10(
        (255.0 ** 2) / mse.clamp_min(torch.finfo(mse.dtype).tiny)
    )
    psnr = torch.where(
        mse == 0, torch.full_like(psnr, float("inf")), psnr
    )

    return psnr.mean()
