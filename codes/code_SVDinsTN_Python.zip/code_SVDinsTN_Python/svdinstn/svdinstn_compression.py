"""PyTorch implementation of SVDinsTN."""

import torch

from svdinstn.torch_ops import (
    my_unfold, my_fold, slice_extraction, prox_l1,
    generate_m, generate_h, stn_composition,
    sub_tn, tnreshape, tn_composition, flatten_f,
)


def _admm_s(x_vec, H, S_old, gama, beta, rho, iteration):
    """Update connection weights using ADMM."""
    Q = S_old.clone()
    P = torch.zeros_like(S_old)
    eps = torch.finfo(S_old.dtype).eps

    tau = (
        gama * S_old.abs().max()
        if S_old.numel()
        else S_old.new_tensor(0.0)
    )
    n_inner = 1 if iteration < 3 else 5

    Ht = H.T
    Htx = Ht @ x_vec
    tempA = Ht @ H + beta * torch.eye(
        H.shape[1], dtype=H.dtype, device=H.device
    )
    tempA_inv = torch.linalg.pinv(tempA, hermitian=True)

    for _ in range(n_inner):
        temp = (beta * Q - P + rho * S_old) / (beta + rho)
        W = 1.0 / (temp.abs() + eps)
        S = prox_l1(temp, tau * W)

        tempC = Htx + beta * S + P
        Q = tempA_inv @ tempC
        P = P + beta * (S - Q)

    return S.reshape(-1)


def _merge(G, S):
    """Absorb connection weights into the tensor network factors."""
    Gnew = [g.clone() for g in G]
    N = len(G)

    for i in range(N - 1):
        for j in range(i + 1, N):
            if S[i][j] is None:
                continue

            shape = [1] * N
            shape[j] = len(S[i][j])
            Gnew[i] = Gnew[i] * S[i][j].reshape(shape)

    return Gnew


def svdinstn_compression(
    X, gama, re_bound, tol=1e-5, maxit=1000,
    mu=1.0, beta=1.0, rho=0.001,
    verbose=True, device=None
):
    """Perform tensor decomposition using SVDinsTN."""
    import numpy as np

    # Initialize the input tensor and computing device.
    device = torch.device(
        device or ("cuda" if torch.cuda.is_available() else "cpu")
    )
    X = torch.as_tensor(X, dtype=torch.float64).to(device)
    XT = X.clone()

    Nway, N = list(X.shape), X.ndim
    eps, total_number = torch.finfo(X.dtype).eps, X.numel()

    # Initialize connection weights from singular values.
    S = [[None] * N for _ in range(N)]
    R = torch.zeros((N, N), dtype=torch.int64, device=device)

    for t in range(N - 1):
        for l in range(t + 1, N):
            sv = torch.linalg.svdvals(slice_extraction(X, N, t, l))
            W = 1.0 / (sv.abs() + eps)
            sv = prox_l1(sv, gama * sv.max() * W)
            S[t][l] = sv[sv >= eps]
            R[t, l] = S[t][l].numel()

    # Initialize normalized tensor network factors.
    tempdim = R + R.T + torch.diag(
        torch.tensor(Nway, dtype=R.dtype, device=device)
    )

    G = []
    for k in range(N):
        g = torch.ones(
            tuple(tempdim[k].tolist()),
            dtype=X.dtype,
            device=device,
        )
        G.append(g / torch.sqrt((g * g).sum(dim=k, keepdim=True)))

    # Initialize convergence metrics and rank history.
    deR, Re_X, CR = 1.0, X.clone(), float("nan")
    output_r = [None] * maxit

    for step in range(1, maxit + 1):
        Xold = Re_X.clone()

        if deR > eps:
            # Update tensor network factors.
            for k in range(N):
                dim_k = tempdim[k].tolist()
                Xk = my_unfold(X, Nway, k)
                Gk = my_unfold(G[k], dim_k, k)
                M = generate_m(G, S, k)

                gram = M @ M.T
                A = gram + (rho + mu) * torch.eye(
                    Gk.shape[1], dtype=X.dtype, device=device
                )
                B = Xk @ M.T + rho * Gk

                G[k] = my_fold(
                    B @ torch.linalg.pinv(A, hermitian=True),
                    dim_k, k
                )

            # Update connection weights.
            for t in range(N - 1):
                for l in range(t + 1, N):
                    H = generate_h(G, S, t, l)
                    S[t][l] = _admm_s(
                        flatten_f(X), H, S[t][l],
                        gama, beta, rho, step
                    )

            # Prune small connection weights and update factor dimensions.
            for t in range(N - 1):
                for l in range(t + 1, N):
                    sv = S[t][l]
                    keep = sv >= 1e-8

                    if torch.any(~keep) and torch.any(keep):
                        S[t][l] = sv[keep]
                        dim_t = tempdim[t].tolist()
                        dim_l = tempdim[l].tolist()

                        Gt = my_unfold(G[t], dim_t, l)[keep, :]
                        Gl = my_unfold(G[l], dim_l, t)[keep, :]

                        rank = S[t][l].numel()
                        tempdim[t, l] = tempdim[l, t] = rank
                        dim_t[l] = dim_l[t] = rank

                        G[t] = my_fold(Gt, dim_t, l)
                        G[l] = my_fold(Gl, dim_l, t)

            # Reconstruct the tensor and record the ranks.
            Re_X = stn_composition(G, S)
            out_r = torch.zeros(
                (N, N), dtype=torch.int64, device=device
            )

            for t in range(N - 1):
                for l in range(t + 1, N):
                    out_r[t, l] = S[t][l].numel()

            output_r[step - 1] = out_r.cpu().numpy()
            OutR = out_r + out_r.T + torch.diag(
                torch.tensor(Nway, dtype=out_r.dtype, device=device)
            )
            CR = (torch.prod(OutR, dim=0).sum() / total_number).item()

            # Check rank stability and merge the factors if stable.
            if step > 10:
                deR = sum(
                    np.linalg.norm(output_r[i] - output_r[i - 1])
                    for i in range(step - 10, step)
                )

                if deR < eps:
                    G = _merge(G, S)
                    mu = 0.0

        else:
            # Update factors after rank stabilization.
            for k in range(N):
                dim_k = tempdim[k].tolist()
                Xk = my_unfold(X, Nway, k)
                Gk = my_unfold(G[k], dim_k, k)
                Grest = tnreshape(sub_tn(G, k), N, k)

                gram = Grest @ Grest.T
                A = gram + (rho + mu) * torch.eye(
                    Gk.shape[1], dtype=X.dtype, device=device
                )
                B = Xk @ Grest.T + rho * Gk

                G[k] = my_fold(
                    torch.linalg.solve(A.T, B.T).T,
                    dim_k, k
                )

            Re_X = tn_composition(G)

        # Evaluate reconstruction errors.
        denom_real = torch.linalg.vector_norm(flatten_f(XT))
        denom_old = torch.linalg.vector_norm(flatten_f(Xold))

        RE_real = (
            torch.linalg.vector_norm(flatten_f(Re_X - XT)) / denom_real
            if denom_real.item()
            else X.new_tensor(0.0)
        )
        RE = (
            torch.linalg.vector_norm(flatten_f(Re_X - Xold)) / denom_old
            if denom_old.item()
            else X.new_tensor(0.0)
        )

        if verbose and (step == 1 or step % 2 == 0):
            print(
                f"SVDinsTN: iter={step} "
                f"RE_real={RE_real.item():.6g} "
                f"RE={RE.item():.6g} CR={CR:.6g}"
            )

        if RE.item() < tol or RE_real.item() < re_bound:
            break

    # Return the reconstruction and optimization information.
    info = {
        "iterations": step,
        "RE_real": RE_real.item(),
        "RE": RE.item(),
        "rank_history": output_r[:step],
        "S": S,
    }

    OutR = output_r[step - 1]
    return Re_X, G, OutR, CR, info
