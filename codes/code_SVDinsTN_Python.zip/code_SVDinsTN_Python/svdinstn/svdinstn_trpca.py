"""PyTorch implementation of SVDinsTN for tensor robust PCA."""

import torch
from svdinstn.my_psnr import my_psnr

from svdinstn.torch_ops import (
    my_unfold, my_fold, slice_extraction, prox_l1, generate_m, generate_h,
    stn_composition, sub_tn, tnreshape, tn_composition, flatten_f,
)


def _merge(G, S):
    """Absorb connection weights into the tensor network factors."""
    Gnew = [g.clone() for g in G]
    N = len(G)

    for i in range(N - 1):
        for j in range(i + 1, N):
            if S[i][j] is not None:
                shape = [1] * N
                shape[j] = S[i][j].numel()
                Gnew[i] = Gnew[i] * S[i][j].reshape(shape)

    return Gnew


def _admm_s(x_vec, H, S_old, gama, beta=1.0, rho=0.001):
    """Update connection weights using ADMM."""
    Q = S_old.clone()
    P = torch.zeros_like(S_old)
    tau = gama * S_old.abs().max()

    # Precompute terms that remain constant during the inner iterations.
    Ht = H.T
    Htx = Ht @ x_vec
    tempA = Ht @ H + beta * torch.eye(
        H.shape[1], dtype=H.dtype, device=H.device
    )
    tempA_pinv = torch.linalg.pinv(tempA, hermitian=True)

    for _ in range(5):
        temp = (beta * Q - P + rho * S_old) / (beta + rho)
        S = prox_l1(temp, tau)
        tempC = Htx + beta * S + P
        Q = tempA_pinv @ tempC
        P = P + beta * (S - Q)

    return S.reshape(-1)


def svdinstn_trpca(
    F, opts, tol=1e-5, maxit=500, mu=1.0, beta=1.0,
    rho=0.001, verbose=True, device=None
):
    """
    Run SVDinsTN-TRPCA.

    Args:
        F: Observed tensor.
        opts: Dictionary containing gama, R, alpha, eta, and optional Xtrue.
        tol: Relative-change stopping tolerance.
        maxit: Maximum number of iterations.
        mu, beta, rho: Algorithm parameters.
        verbose: Whether to print iteration information.
        device: Computation device.

    Returns:
        X: Reconstructed tensor on the selected device.
        Out: Convergence, PSNR, and rank information on the selected device.
        OutR: Rank history as a list of device-resident tensors.
    """
    device = torch.device(
        device if device is not None else
        ("cuda" if torch.cuda.is_available() else "cpu")
    )

    # Move the input and all optimization variables to the selected device.
    F = torch.as_tensor(F, dtype=torch.float64, device=device)
    X = F.clone()
    E = torch.zeros_like(F)

    gama = torch.as_tensor(opts["gama"], dtype=F.dtype, device=device)
    R = torch.as_tensor(
        opts["R"], dtype=torch.int64, device=device
    ).clone()

    alpha, eta = float(opts["alpha"]), float(opts["eta"])
    N, Nway = F.ndim, list(F.shape)
    eps = torch.finfo(F.dtype).eps

    # Initialize connection weights using truncated singular values.
    S = [[None for _ in range(N)] for _ in range(N)]

    for t in range(N - 1):
        for l in range(t + 1, N):
            sv = torch.linalg.svdvals(slice_extraction(X, N, t, l))
            rank = min(int(R[t, l].item()), sv.numel())
            sv = prox_l1(sv[:rank], gama * sv[:rank].max())
            S[t][l] = sv[sv >= eps]
            R[t, l] = S[t][l].numel()

    # Determine factor dimensions and initialize normalized factors.
    tempdim = R + R.T + torch.diag(
        torch.tensor(Nway, dtype=R.dtype, device=device)
    )

    G = []
    for k in range(N):
        g = torch.ones(
            tuple(int(v) for v in tempdim[k].tolist()),
            dtype=F.dtype, device=device
        )
        G.append(g / torch.sqrt(g.pow(2).sum(dim=k, keepdim=True)))

    # Keep convergence metrics and rank history on the selected device.
    deR = 1.0
    Out = {
        "R": torch.zeros((N, N), dtype=torch.int64, device=device),
        "RE": [],
        "PSNR": [],
    }
    OutR = [None] * maxit

    Xtrue = opts.get("Xtrue")
    if Xtrue is not None:
        Xtrue = torch.as_tensor(Xtrue, dtype=F.dtype, device=device)

    # Main optimization loop.
    for step in range(1, maxit + 1):
        Xold = X.clone()

        if deR > eps:
            # Update tensor network factors.
            for k in range(N):
                dim_k = [int(v) for v in tempdim[k].tolist()]
                Xk = my_unfold(X, Nway, k)
                Gk = my_unfold(G[k], dim_k, k)
                M = generate_m(G, S, k)

                tempC = Xk @ M.T + rho * Gk
                tempA = M @ M.T + (rho + mu) * torch.eye(
                    Gk.shape[1], dtype=F.dtype, device=device
                )

                G[k] = my_fold(
                    tempC @ torch.linalg.pinv(
                        tempA, hermitian=True
                    ),
                    dim_k, k
                )

            # Update connection weights using ADMM.
            x_vec = flatten_f(X)

            for t in range(N - 1):
                for l in range(t + 1, N):
                    H = generate_h(G, S, t, l)
                    S[t][l] = _admm_s(
                        x_vec, H, S[t][l], gama, beta, rho
                    )

                    # Prune negligible connection weights.
                    keep = S[t][l] >= eps

                    if bool(torch.any(~keep).item()) and bool(
                        torch.any(keep).item()
                    ):
                        S[t][l] = S[t][l][keep]

                        dim_t = [int(v) for v in tempdim[t].tolist()]
                        dim_l = [int(v) for v in tempdim[l].tolist()]

                        Gt = my_unfold(G[t], dim_t, l)[keep, :]
                        Gl = my_unfold(G[l], dim_l, t)[keep, :]

                        rank = S[t][l].numel()
                        tempdim[t, l] = rank
                        tempdim[l, t] = rank
                        dim_t[l] = rank
                        dim_l[t] = rank

                        G[t] = my_fold(Gt, dim_t, l)
                        G[l] = my_fold(Gl, dim_l, t)

            # Update the sparse corruption tensor and reconstruction.
            E = prox_l1(
                (rho * E + eta * (F - X)) / (rho + eta),
                alpha / (rho + eta)
            )
            X = (
                stn_composition(G, S)
                + rho * Xold
                + eta * (F - E)
            ) / (1.0 + rho + eta)

            # Record the rank matrix directly on the selected device.
            out_r = torch.zeros(
                (N, N), dtype=torch.int64, device=device
            )
            for t in range(N - 1):
                for l in range(t + 1, N):
                    out_r[t, l] = S[t][l].numel()

            OutR[step - 1] = out_r.detach()
            Out["R"] = out_r.detach()

            # Check rank stability without copying rank matrices to CPU.
            if step > 10:
                deR_tensor = torch.zeros((), dtype=F.dtype, device=device)

                for i in range(step - 10, step):
                    diff = OutR[i] - OutR[i - 1]
                    deR_tensor = deR_tensor + torch.linalg.vector_norm(
                        diff.to(F.dtype)
                    )

                deR = deR_tensor.item()

                if deR < eps:
                    G = _merge(G, S)

        else:
            # Update factors after the rank structure stabilizes.
            for k in range(N):
                dim_k = [int(v) for v in tempdim[k].tolist()]
                Xk = my_unfold(X, Nway, k)
                Gk = my_unfold(G[k], dim_k, k)
                Grest = tnreshape(sub_tn(G, k), N, k)

                tempC = Xk @ Grest.T + rho * Gk
                tempA = Grest @ Grest.T + (rho + mu) * torch.eye(
                    Gk.shape[1], dtype=F.dtype, device=device
                )

                G[k] = my_fold(
                    torch.linalg.solve(tempA.T, tempC.T).T,
                    dim_k, k
                )

            # Update the sparse corruption tensor and reconstruction.
            E = prox_l1(
                (rho * E + eta * (F - X)) / (rho + eta),
                alpha / (rho + eta)
            )
            X = (
                tn_composition(G)
                + rho * Xold
                + eta * (F - E)
            ) / (1.0 + rho + eta)

        # Calculate relative change on the selected device.
        RE = (
            torch.linalg.vector_norm(flatten_f(X - Xold))
            / torch.linalg.vector_norm(flatten_f(Xold)).clamp_min(eps)
        )
        Out["RE"].append(RE)

        # Compute slice-wise PSNR on the selected device.
        if Xtrue is not None:
            psnr = my_psnr(255.0 * Xtrue, 255.0 * X)
            Out["PSNR"].append(psnr)

        # Printing requires scalar synchronization with the CPU.
        if verbose and (step == 1 or step % 5 == 0):
            msg = (
                f"SVDinsTN-TRPCA: iter={step} "
                f"RE={RE.item():.6g}"
            )
            if Xtrue is not None:
                msg += f" PSNR={Out['PSNR'][-1].item():.6f}"
            print(msg)

        if RE.item() < tol:
            break

    return X, Out, OutR[:step]
