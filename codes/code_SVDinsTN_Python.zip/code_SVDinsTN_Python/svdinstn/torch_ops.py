"""PyTorch tensor-network operations for CPU and CUDA."""
import math
import torch


def _shape_n(x, n):
    """Return the first n dimensions, padding with ones if necessary."""
    shape = list(x.shape)
    if len(shape) < n:
        shape += [1] * (n - len(shape))
    return shape[:n]


def reshape_f(x, shape):
    """Reshape a tensor using MATLAB/Fortran ordering."""
    shape = tuple(int(v) for v in shape)

    if x.ndim <= 1:
        return (
            x.reshape(tuple(reversed(shape))).permute(
                tuple(reversed(range(len(shape))))
            )
            if len(shape) > 1
            else x.reshape(shape)
        )

    # Reverse the axes to reproduce column-major element ordering.
    rev_axes = tuple(reversed(range(x.ndim)))
    y = x.permute(rev_axes).contiguous()
    y = y.reshape(tuple(reversed(shape)))

    return (
        y.permute(tuple(reversed(range(len(shape)))))
        if len(shape) > 1
        else y.reshape(shape)
    )


def flatten_f(x):
    """Flatten a tensor using MATLAB/Fortran ordering."""
    if x.ndim <= 1:
        return x.reshape(-1)

    # Reverse the axes before flattening.
    return x.permute(
        tuple(reversed(range(x.ndim)))
    ).contiguous().reshape(-1)


def my_unfold(W, dim, i):
    """Unfold a tensor along mode i into a matrix."""
    dim = list(dim)
    order = [i] + [j for j in range(len(dim)) if j != i]

    # Move mode i to the first position.
    return reshape_f(W.reshape(dim).permute(order), (dim[i], -1))


def my_fold(W, dim, i):
    """Fold a matrix back into a tensor along mode i."""
    dim = list(dim)
    order = [i] + [j for j in range(len(dim)) if j != i]
    trans_shape = [dim[j] for j in order]

    # Restore the tensor dimensions and original mode order.
    tmp = reshape_f(W, trans_shape)
    inverse = [order.index(j) for j in range(len(order))]

    return reshape_f(tmp.permute(inverse), dim)


def tn_composition(G):
    """Contract all tensor-network cores to reconstruct the tensor."""
    N = len(G)
    m, n = [1], [0]
    out = G[0]
    M = N

    # Contract the cores sequentially along their shared rank modes.
    for i in range(1, N):
        out = torch.tensordot(out, G[i], dims=(m, n))
        M = M + N - 2 * i
        n = n + [i]
        tempm = 1 + i * (N - i)

        if i > 1:
            m[1:] = [
                v - j for v, j in zip(m[1:], range(1, i))
            ]

        m = m + [tempm]

    return out


def stn_composition(G, S):
    """Reconstruct the tensor with diagonal rank-weight matrices."""
    G = [g.clone() for g in G]
    N = len(G)

    # Absorb each diagonal matrix into its corresponding core.
    for i in range(N - 1):
        for j in range(i + 1, N):
            if S[i][j] is not None:
                G[i] = torch.tensordot(
                    G[i],
                    torch.diag(S[i][j]),
                    dims=([i + 1], [0])
                )

    return tn_composition(G)


def prox_l1(b, lam):
    """Apply the element-wise proximal operator of the L1 norm."""
    return (
        torch.maximum(torch.zeros_like(b), b - lam)
        + torch.minimum(torch.zeros_like(b), b + lam)
    )


def slice_extraction(X, N, i, j):
    """Compute the mean of all mode-(i, j) slices."""
    # Move modes i and j to the first two positions.
    a = [k for k in range(N) if k not in (i, j)]
    Xp = X.permute([i, j] + a)

    # Combine the remaining modes into a single dimension.
    Xp = Xp.reshape(Xp.shape[0], Xp.shape[1], -1)

    # Average over all slices associated with the remaining modes.
    return torch.mean(Xp, dim=2)


def tnreshape(Grest, N, i):
    """Reshape the contracted cores into a matrix for mode i."""
    Nway = _shape_n(Grest, 2 * (N - 1))
    m, n = [], []

    # Determine the row and column modes from the contraction order.
    for k in range(1, N):
        if k < i + 1:
            m.append(2 * k - 1)
            n.append(2 * k - 2)
        else:
            m.append(2 * k - 2)
            n.append(2 * k - 1)

    # Group the selected modes into matrix rows and columns.
    tempG = Grest.reshape(Nway).permute(m + n)

    return reshape_f(
        tempG,
        (
            int(math.prod([Nway[q] for q in m])),
            int(math.prod([Nway[q] for q in n]))
        )
    )


def sub_tn(G, k):
    """Contract all cores except the k-th core."""
    G = list(G)
    N = len(G)

    # Reorder the cores according to the MATLAB implementation.
    a = list(range(k + 1, N)) + list(range(0, k + 1))

    # Permute the modes of the remaining cores.
    for i in list(range(k)) + list(range(k + 1, N)):
        G[i] = G[i].permute(a)

    m, n = [1], [0]
    out = G[a[0]]
    M = N

    # Contract the selected cores sequentially.
    for i in range(1, N - 1):
        out = torch.tensordot(out, G[a[i]], dims=(m, n))
        M = M + N - 2 * i
        n = n + [i]
        tempm = 1 + i * (N - i)

        if i > 1:
            m[1:] = [
                v - j for v, j in zip(m[1:], range(1, i))
            ]

        m = m + [tempm]

    # Restore the required mode ordering.
    p = []
    for i in range(N - k - 1):
        p.extend([2 * i + 1, 2 * i])

    out = out.permute(
        p + list(range(2 * (N - k - 1), 2 * (N - 1)))
    )

    out = out.permute(
        list(range(2 * (N - k - 1), 2 * (N - 1)))
        + list(range(2 * (N - k - 1)))
    )

    return out


def _fctn_rest_paper(G, a):
    """Contract the tensor-network cores in the specified order."""
    N = len(G)
    m, n = [1], [0]
    out = G[a[0]]
    M = N

    # Sequentially contract the shared rank modes.
    for i in range(1, N - 1):
        out = torch.tensordot(out, G[a[i]], dims=(m, n))
        M = M + N - 2 * i
        n = n + [i]
        tempm = 1 + i * (N - i)

        if i > 1:
            m[1:] = [
                v - j for v, j in zip(m[1:], range(1, i))
            ]

        m = m + [tempm]

    return out


def generate_m(G, S, k):
    """Generate the matrix M_k for updating the k-th core."""
    G = [g.clone() for g in G]
    N = len(G)

    # Reorder the cores to prepare for tensor contractions.
    a = list(range(k + 1, N)) + list(range(k + 1))

    for i in list(range(k)) + list(range(k + 1, N)):

        # Absorb the diagonal matrices associated with each core.
        for j in range(i + 1, N):
            if S[i][j] is not None:
                G[i] = torch.tensordot(
                    G[i],
                    torch.diag(S[i][j]),
                    dims=([i + 1], [0])
                )

        # Absorb the connection between modes k and i.
        if i > k and S[k][i] is not None:
            G[i] = torch.tensordot(
                G[i],
                torch.diag(S[k][i]),
                dims=([k], [0])
            )
            G[i] = G[i].permute(
                list(range(k))
                + [N - 1]
                + list(range(k, N - 1))
            )

        G[i] = G[i].permute(a)

    # Contract the remaining cores.
    M = _fctn_rest_paper(G, a)

    # Restore the mode order required for matrix unfolding.
    M = M.permute(
        list(range(2 * (N - k - 1), 2 * (N - 1)))
        + list(range(2 * (N - k - 1)))
    )

    Nway = _shape_n(M, 2 * N - 2)
    m = [2 * q + 1 for q in range(N - 1)]
    n = [2 * q for q in range(N - 1)]

    # Unfold the contracted tensor into M_k.
    tempG = M.reshape(Nway).permute(m + n)

    return reshape_f(
        tempG,
        (
            int(math.prod([Nway[q] for q in m])),
            int(math.prod([Nway[q] for q in n]))
        )
    )


def generate_h(G, S, t, l):
    """Generate the matrix H_{t,l} for updating S_{t,l}."""
    # Clone the cores to avoid modifying the input tensors.
    G = [g.clone() for g in G]
    N = len(G)

    # Compute the number of entries in the reconstructed tensor.
    dim = 1
    for i in range(N):
        dim *= G[i].shape[i]

    # The number of columns equals the current TN rank.
    R = S[t][l].numel()

    # Absorb diagonal matrices into cores other than G_t.
    for i in list(range(t)) + list(range(t + 1, N - 1)):
        for j in range(i + 1, N):
            if S[i][j] is not None:
                G[i] = torch.tensordot(
                    G[i],
                    torch.diag(S[i][j]),
                    dims=([i + 1], [0])
                )

    # Absorb connections between mode t and modes before l.
    for j in range(t + 1, l):
        if S[t][j] is not None:
            G[t] = torch.tensordot(
                G[t],
                torch.diag(S[t][j]),
                dims=([t + 1], [0])
            )

    # Absorb connections between mode t and modes after l.
    for j in range(l + 1, N):
        if S[t][j] is not None:
            G[t] = torch.tensordot(
                G[t],
                torch.diag(S[t][j]),
                dims=([t + 2], [0])
            )

    # Move the (t, l) rank mode to the required position.
    perm = (
        list(range(t + 1))
        + list(range(t + 2, l + 1))
        + [t + 1]
        + list(range(l + 1, N))
    )
    G[t] = G[t].permute(perm)

    # Unfold G_t and G_l along their shared rank mode.
    sizeGt = _shape_n(G[t], N)
    sizeGl = _shape_n(G[l], N)

    Gt = my_unfold(G[t], sizeGt, l)
    Gl = my_unfold(G[l], sizeGl, t)

    # Remove the selected rank dimensions before folding.
    sizeGt[l] = 1
    sizeGl[t] = 1

    # Each column corresponds to one component of S_{t,l}.
    H = torch.zeros(
        (dim, R),
        dtype=G[0].dtype,
        device=G[0].device
    )

    for i in range(R):
        # Select the i-th component from both connected cores.
        G[t] = my_fold(Gt[i:i + 1, :], sizeGt, l)
        G[l] = my_fold(Gl[i:i + 1, :], sizeGl, t)

        # Contract the cores and vectorize the resulting tensor.
        H[:, i] = flatten_f(tn_composition(G))

    return H