import torch

def my_psnr(imagery1, imagery2):
    """
    Inputs: image values in [0, 255].
    The first two dimensions form each 2D slice.
    Remaining dimensions index the slices.
    """
    H, W = imagery1.shape[:2]

    if imagery1.ndim > 2:
        perm = [0, 1] + list(range(imagery1.ndim - 1, 1, -1))
        imagery1 = imagery1.permute(perm).contiguous().reshape(H, W, -1)
        imagery2 = imagery2.permute(perm).contiguous().reshape(H, W, -1)
    else:
        imagery1 = imagery1.reshape(H, W, -1)
        imagery2 = imagery2.reshape(H, W, -1)

    mse = ((imagery1.double() - imagery2.double()) ** 2).mean(dim=(0, 1))
    return (10 * torch.log10(255.0**2 / mse)).mean()