"""Demo for SVDinsTN tensor compression."""

import time
import numpy as np
import torch
from scipy.io import loadmat

from svdinstn.svdinstn_compression import svdinstn_compression


def main():
    # Load the input tensor.
    X = loadmat("data/Truck_test.mat")["X"].astype(np.float64)

    gama = 0.0002
    re_bound = 0.1

    # Run SVDinsTN and measure the elapsed time.
    start = time.perf_counter()

    Re_X, G, OutR, CR, info = svdinstn_compression(
        X, gama, re_bound
    )

    if Re_X.device.type == "cuda":
        torch.cuda.synchronize()

    elapsed = time.perf_counter() - start

    # Evaluate the relative reconstruction error.
    Re_X = Re_X.detach().cpu().numpy()
    RE = np.linalg.norm(Re_X - X) / max(
        np.linalg.norm(X), np.finfo(float).eps
    )

    print(f"Elapsed time: {elapsed:.2f} s")
    print(f"Relative reconstruction error: {RE:.6g}")
    print(f"Iterations: {info['iterations']}")
    print(f"CR: {CR}")


if __name__ == "__main__":
    main()
