"""Demo for SVDinsTN tensor completion."""

from pathlib import Path
import time

import numpy as np
import torch
from scipy.io import loadmat

from svdinstn.svdinstn_completion import svdinstn_tc
from svdinstn.my_psnr import my_psnr


def main():
    # Load the reference tensor.
    data = loadmat(Path("data/color_news_test.mat"))
    Xtrue_np = np.asarray(data["X"], dtype=np.float64)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    Xtrue = torch.as_tensor(Xtrue_np, dtype=torch.float64, device=device)

    # Generate random observations.
    sample_ratio = 0.10
    torch.manual_seed(6)
    if device.type == "cuda":
        torch.cuda.manual_seed_all(2)

    Omega = torch.rand_like(Xtrue) < sample_ratio
    F = torch.where(Omega, Xtrue, torch.zeros_like(Xtrue))

    # Set parameters.
    opts = {
        "R": np.array([
            [0, 60, 3, 25],
            [0, 0, 3, 25],
            [0, 0, 0, 3],
            [0, 0, 0, 0],
        ], dtype=np.int64),
        "gama": 0.0004,
        "Xtrue": Xtrue,
    }

    print(f"Device: {device}")
    print(f"Sampling ratio: {sample_ratio:.2f}")
    print("Performing SVDinsTN-TC...")

    # Run tensor completion.
    if device.type == "cuda":
        torch.cuda.synchronize()
    start = time.perf_counter()

    Re_tensor, Out, OutR = svdinstn_tc(
        F, Omega, opts, device=device, verbose=True
    )

    if device.type == "cuda":
        torch.cuda.synchronize()
    elapsed = time.perf_counter() - start

    # Evaluate slice-wise PSNR.
    psnr = my_psnr(255.0 * Xtrue, 255.0 * Re_tensor)

    print(f"PSNR: {psnr:.4f} dB")
    print(f"Elapsed time: {elapsed:.2f} s")
    print(f"Iterations: {len(Out['RE'])}")


if __name__ == "__main__":
    main()
