"""Demo for SVDinsTN-TRPCA."""

from pathlib import Path
import time

import numpy as np
import torch
from scipy.io import loadmat

from svdinstn.svdinstn_trpca import svdinstn_trpca
from svdinstn.my_psnr import my_psnr


def main():
    # Load the reference tensor.
    data_path = Path("data/color_news_test.mat")
    mat = loadmat(data_path)
    Xtrue_np = np.asarray(mat["X"], dtype=np.float64)

    # Normalize the data to [0, 1] if necessary.
    if Xtrue_np.min() < 0 or Xtrue_np.max() > 1:
        Xtrue_np = (
            (Xtrue_np - Xtrue_np.min())
            / max(
                Xtrue_np.max() - Xtrue_np.min(),
                np.finfo(np.float64).eps,
            )
        )

    # Select the computing device.
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    Xtrue = torch.as_tensor(
        Xtrue_np, dtype=torch.float64, device=device
    )

    # Generate salt-and-pepper corruption.
    corruption_ratio = 0.4
    torch.manual_seed(5)

    if device.type == "cuda":
        torch.cuda.manual_seed_all(5)

    mask = torch.rand_like(Xtrue) < corruption_ratio
    noise = torch.randint(
        0, 2, Xtrue.shape, device=device
    ).to(Xtrue.dtype)
    F = torch.where(mask, noise, Xtrue)

    # Set the parameters from demo_TRPCA.m.
    opts = {
        "R": np.array([
            [0, 60, 3, 25],
            [0, 0, 3, 25],
            [0, 0, 0, 3],
            [0, 0, 0, 0],
        ], dtype=np.int64),
        "gama": 0.00065,
        "alpha": 0.01,
        "eta": 1.0,
        "Xtrue": Xtrue,
    }

    print(f"Device: {device}")
    print("Performing SVDinsTN-TRPCA...")

    # Run the algorithm and measure the elapsed time.
    if device.type == "cuda":
        torch.cuda.synchronize()
    start = time.perf_counter()

    Re_tensor, Out, OutR = svdinstn_trpca(
        F, opts, device=device, verbose=True
    )

    if device.type == "cuda":
        torch.cuda.synchronize()
    elapsed = time.perf_counter() - start

    # Evaluate reconstruction quality using slice-wise PSNR.
    psnr = my_psnr(255.0 * Xtrue, 255.0 * Re_tensor)

    print(f"PSNR: {psnr.item():.4f} dB")
    print(f"Elapsed time: {elapsed:.2f} s")
    print(f"Iterations: {len(Out['RE'])}")


if __name__ == "__main__":
    main()
