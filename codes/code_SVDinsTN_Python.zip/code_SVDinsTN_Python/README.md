# SVDinsTN: PyTorch Implementation

This repository provides PyTorch implementations of **SVDinsTN**, a
tensor network paradigm for efficient tensor representation and
structure search. The code supports CPU and CUDA execution and includes
demos for tensor compression, tensor completion, tensor robust principal
component analysis (TRPCA), and multitemporal remote-sensing cloud
removal.

## Contents

-   `demo_compression.py`: tensor compression.
-   `demo_completion.py`: tensor completion from incomplete
    observations.
-   `demo_trpca.py`: tensor robust PCA for sparse-corruption removal.
-   `demo_cloud_removal.py`: multitemporal remote-sensing cloud removal.
-   `svdinstn/`: algorithm implementations and tensor-network
    operations.
-   `data/`: example MATLAB `.mat` datasets used by the demos.

## Requirements

-   Python 3.8 (the development environment used for testing)
-   PyTorch
-   NumPy
-   SciPy
-   CUDA-compatible GPU and drivers for GPU acceleration

The algorithms use double-precision (`float64`) tensors. GPU execution
is selected when CUDA is available; otherwise, the algorithms can run on
the CPU.

Install the required packages in your Python environment. For example:

``` bash
pip install numpy scipy torch
```

For GPU acceleration, install a PyTorch build compatible with your CUDA
environment. See the official [PyTorch installation
guide](https://pytorch.org/get-started/locally/).

## Run the Demos

Run commands from the repository root directory:

``` bash
python demo_compression.py
python demo_completion.py
python demo_trpca.py
python demo_cloud_removal.py
```

The demos load their example data from the `data/` directory:

  -----------------------------------------------------------------------
  Demo                                Input data
  ----------------------------------- -----------------------------------
  Tensor compression                  `data/Truck_test.mat`

  Tensor completion                   `data/color_news_test.mat`

  Tensor TRPCA                        `data/color_news_test.mat`

  Multitemporal cloud removal         `data/testMTRSI.mat`,
                                      `data/cloudMask.mat`
  -----------------------------------------------------------------------

The `.mat` files must contain the variables expected by the
corresponding demo scripts. For example, the compression, completion,
and TRPCA demos use `X`; the cloud-removal demo uses `Clean` and `Mask`.

## Citation

If you use this code in your research, please cite the relevant papers:

**1. IEEE TPAMI, 2026**

Yu-Bang Zheng, Xi-Le Zhao, Heng-Chao Li, Junhua Zeng, Chao Li, Qibin
Zhao, Ting-Zhu Huang, and Qing Zhu. "A Structure-Revealing Tensor
Network Paradigm and Its Applications." *IEEE Transactions on Pattern
Analysis and Machine Intelligence*, 2026.

**2. CVPR, 2024**

Yu-Bang Zheng, Xi-Le Zhao, Junhua Zeng, Chao Li, Qibin Zhao, Heng-Chao
Li, and Ting-Zhu Huang. "SVDinsTN: A Tensor Network Paradigm for
Efficient Structure Search from Regularized Modeling Perspective."
*Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern
Recognition (CVPR)*, 2024.

```
