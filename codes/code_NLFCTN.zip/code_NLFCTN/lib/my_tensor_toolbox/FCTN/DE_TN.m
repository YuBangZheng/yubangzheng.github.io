function [G, Out] = DE_TN(X,opts)
if isfield(opts, 'tol');         tol   = opts.tol;              end
if isfield(opts, 'maxit');       maxit = opts.maxit;    end
if isfield(opts, 'rho');         rho   = opts.rho;              end
if isfield(opts, 'R');           R     = opts.R;        end

N = ndims(X); 
Nway = size(X);
tempdim = diag(Nway)+R+R';
G = cell(1,N);
for i = 1:N
    G{i} = rand(tempdim(i,:));
end

Out.real=[];Out.res=[];
Xhat = tnprod(G);
for k = 1:maxit
    Xold = Xhat;
    % Update G 
    for i = 1:N
        Xi = my_Unfold(X,Nway,i);
        Gi = my_Unfold(G{i},tempdim(i,:),i);
        Girest = tnreshape(tnprod_rest(G,i),N,i);
        tempC = Xi*Girest'+rho*Gi;
        tempA = Girest*Girest'+rho*eye(size(Gi,2));
        G{i}  = my_Fold(tempC*pinv(tempA),tempdim(i,:),i);
    end
    
    % Update X 
    Xhat = (tnprod(G)+rho*Xold)/(1+rho);

    
    %% check the convergence
    real = norm(X(:)-Xhat(:))/norm(X(:));
    res  = norm(Xold(:)-Xhat(:))/norm(Xold(:));
    Out.res = [Out.res,res];
    Out.real = [Out.real,real];
    fprintf('DE-TN: iter = %d   real=%5.8f   res=%5.8f   \n', k, real, res);
    if res < tol 
        break;
    end
end
end
    

