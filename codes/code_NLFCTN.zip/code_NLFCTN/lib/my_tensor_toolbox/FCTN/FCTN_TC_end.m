 % 'inc_FCTN_TC_end.m' supposes that the size of the factor G_k is 
 % R_{1,k}*R_{2,k}*...*R_{k-1,k}*R_{k,k+1}*...*R_{k,N}*I_k. 
 % (can set the FCTN rank as 1 in Matlab)
   
function [X, G, Out] = FCTN_TC_end(F,Omega,opts)
if isfield(opts, 'maxit');       maxit = opts.maxit;            end
if isfield(opts, 'rho');         rho   = opts.rho;              end
if isfield(opts, 'R');           R     = opts.R;                end

Omega = Omega>0;
N = ndims(F); 
Nway = size(F);
X = F;

tempdim = R+R';  tempdim(tempdim==0) = []; 
tempdim = reshape(tempdim,N-1,N);   tempdim = tempdim'; 
tempdim(:,end+1) = Nway';

G = cell(1,N);
for i = 1:N
    G{i} = rand(tempdim(i,:)); 
end

Out.RSE = [];Out.RSE_real = [];

for k = 1:maxit
    Xold = X;
    % Update G 
    for i = 1:N
        Xi = my_Unfold(X,Nway,i);
        Gi = my_Unfold(G{i},tempdim(i,:),N);
        Girest = tnreshape_new(tnprod_rest_new(G,i),N);
        tempC = Xi*Girest'+rho*Gi;
        tempA = Girest*Girest'+rho*eye(size(Gi,2));
        G{i}  = my_Fold(tempC*pinv(tempA),tempdim(i,:),N);
    end
    
    % Update X 
    X = (tnprod_new(G)+rho*Xold)/(1+rho);
    X(Omega) = F(Omega);
end
end
    

